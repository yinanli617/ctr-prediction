package dot
