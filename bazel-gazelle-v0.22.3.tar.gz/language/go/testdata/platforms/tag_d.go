//+build darwin

package platforms

import _ "example.com/repo/platforms/darwin"
