// +build !cgo

package platforms
