output_groups functionality
===========================

Tests to ensure the supported `output_groups` are working as expected.

compilation_outputs_test
------------------------

Checks that the `compilation_outputs` output group is populated with the
compiled archives from `go_library`, `go_test`, and `go_binary` targets.
