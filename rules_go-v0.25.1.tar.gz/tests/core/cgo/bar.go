package main

// void bar();
import "C"

func main() {
	C.bar()
}
