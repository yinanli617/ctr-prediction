package dep

import "os"

type T struct {
	F *os.File
}
