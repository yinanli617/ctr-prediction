package embed

import "package_height/dep"

type T struct {
	F dep.T
}
