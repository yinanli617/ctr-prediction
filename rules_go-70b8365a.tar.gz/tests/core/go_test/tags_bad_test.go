// +build !good

package tags_test

import "testing"

func Test(t *testing.T) {
	t.Fail()
}
