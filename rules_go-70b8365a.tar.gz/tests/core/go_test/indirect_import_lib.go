package indirect_import

var X string = "not set"
