package cgo_filtered

var Value = 42
