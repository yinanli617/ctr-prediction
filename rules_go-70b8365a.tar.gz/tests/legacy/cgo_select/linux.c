const char* goos = "linux";
