# bazel-rules

Repository for custom bazel rules and bazel tooling used at Pinterest.

## build-collector
The `build-collector` CLI is a go binary that finds the changed files between two commits and reports the bazel targets to be built. See the [[ build-collector/README.md/ | build-collector README.md]] for more info.

## Release Macros
This repo defines a few custom release marcos (`flink_release`, `container_release`, `hadoop_release`, `pkg_release`, `s3_release`). The release macros are wrapped by an internal rule called `artifact_release`. This rule is a private rule used only by `build-collector`. The wrapper rule is added to each release macro's implementation in order to group the release artifacts execute them in the correct order. The generated artifact_release rule is aliased to the dev version of it's corresponding release macro. Except in the case of `flink_release` where we currently don't have a dev version of the rule.
