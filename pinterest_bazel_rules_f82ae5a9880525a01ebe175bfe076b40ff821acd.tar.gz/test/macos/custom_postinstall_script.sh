#!/bin/bash

echo "Test package installed at $(date)" > /tmp/postinstall-test-out
