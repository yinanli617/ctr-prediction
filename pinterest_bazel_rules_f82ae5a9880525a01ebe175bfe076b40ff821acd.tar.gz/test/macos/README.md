MacOS Package Test
==================

To test building a macOS package, run:
```
$ bazel build //test/macos:package_macos_test
```

The resulting package can be installed via:
```
$ sudo installer -dumplog -verboseR -pkg <package> -target /
```

Note: Make sure to set -target to "/", as that's what is expected
by the test package. Instructions for removing test files are listed
in this README below.

After installation a postinstall script should generate a timestamp file:
```
$ cat /tmp/postinstall-test-out
Test package installed at Wed Feb 12 15:33:51 PST 2020
```

The timestamp file will be cleaned up on reboot, or you can run:
```
$ sudo rm -f /tmp/postinstall-test-out
```

And finally, to uninstall the package:
```
$ cd /usr/local
$ sudo rm -f $(pkgutil --only-files --files com.pinterest.package.macos.test)
$ sudo pkgutil --forget com.pinterest.package.macos.test
```

Note: You can also use an uninstaller like https://github.com/bgandon/pkg-uninstall
for cleanup instead of removing the files manually.
