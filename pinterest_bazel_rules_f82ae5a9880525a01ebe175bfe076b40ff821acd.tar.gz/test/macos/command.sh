#!/bin/bash

echo "package-test-command"
