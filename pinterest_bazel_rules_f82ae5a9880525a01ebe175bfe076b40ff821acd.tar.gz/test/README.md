Rule Tests
==================

*Currently requires bazel 0.23.1*

Push rules will publish an artifact when run. Manifest rules will
create a manifest JSON file when run. Release macros wrap multiple
push/manifest rules.

Push Rules
==========

ecr_push
--------
Pushes a container to ECR, usually defined by `container_release`.
This is actually a macro that defines 2 dependent rules (repo
creation and image push), and a final rule that sets up
authorization (with hologram) and then calls both rules.
Expected repo creation to succeed with an already exists warning
but image push to fail due to IAM role permissions.
```
bazel run //test:ecr_push
```

flink_push
----------
Pushes a jar file to s3, only used for debugging as we want to
use `flink_release` macro in optimus. This should only work in
CI due to s3 permission for prod-only deployables.
```
bazel run //test:flink_push
```

hadoop_push
-----------
Pushes to s3 dev bucket for hadoop. Hologram permission should
automatically be set by the rule.
```
bazel run //test:hadoop_dev_push
```

teletraan_push
--------------
Pushes a teletraan tarball to s3, and then registers that tarball
as a private build (`env` is `dev`) with teletraan. Will ask for
ldap password to get a knox token. The build will show up at
https://deploy.pinadmin.com/builds/names/bazel_test/builds/.
```
bazel run //test:teletraan_push
```

Manifest Rules
==============

hermez_manifest
---------------
Creates a hermez yaml manifest for use in jenkins builds. The rule
generates a JSON list of dictionaries. Each dictionary contains
parameters to the artifactory publish job. Most use cases should
have a release macro wrapper as there will be a matching deployable
that is pushed.
```
bazel run //test:hermez_manifest -- $(pwd)/publish_manifest.json
```
Make sure to check the output that the merge succeeds here.

Release Rules
=============

flink_release
-------------
Combines `flink_push` and `hermez_manifest`. Note the macro produces
2+ rules with suffix `_push` and `_manifest`.
```
bazel run //test:flink_release_push
bazel run //test:flink_release_manifest -- $(pwd)/manifest.json
```

container_release
-----------------
Combines `ecr_push`, `container_push`, `teletraan_push` and `hermez_manifest`.
Note the macro produces multiple rules with suffix `_push` and `_manifest`.
Hologram will setup permissions for teletraan push but not ECR.

First find all rules that don't have `tags = ["no-ci", "no-dev"]`:
```
$ bazel query 'attr("tags", "container_release", //test/...) except (attr("tags", "no-ci", //test/...) intersect attr("tags", "no-dev", //test/...))'
//test:container_release_teletraan_bazel_release_test_prod_push
//test:container_release_teletraan_bazel_release_test_dev_push
//test:container_release_hermez_prod_manifest
//test:container_release_container_bazel-rules-ubuntu18.04_prod_push
//test:container_release_container_bazel-rules-ubuntu18.04_dev_push
```
Then run each one, starting from last in list. For example for a dev
teletraan build:
```
bazel run //test:container_release_container_bazel-rules-ubuntu18.04_dev_push
bazel run //test:container_release_teletraan_bazel_release_test_dev_push
```

hadoop_release
--------------
Combines two `hadoop_push` rules, one with `env="dev"` and the other with `env="prod"`.
Also adds tags `"no-ci"` to dev push, and `"no-dev"` to prod push.
```
bazel run //test:hadoop_release_prod
bazel run //test:hadoop_release_dev
```

pkg_release
-----------
Creates a debian manifest for use in jenkins builds. The rule
generates a JSON list of dictionaries. Each dictionary contains
parameters to artifactory publish.
```
bazel run $BAZEL_DEFS //test:deb_manifest.ci -- $(pwd)/publish_manifest.json
```
Make sure to check the output that the merge succeeds here.

s3_release
----------
Creates a prod and a dev version of the `s3_push` rule to 
push file `foo.txt` to s3 in `datausers` bucket under key
- `<key_prefix>/bazel_s3_push_artifacts/{GIT_COMMIT_SHA}`

REQUIRED: `{GIT_COMMIT_SHA}` stamp variable defined.
```
# without key prefix
bazel run //test:ci_s3_release.ci # runs prod rule that our ci pipeline will use
bazel run //test:ci_s3_release  #to test the error case
bazel run //test:dev_s3_release # runs dev rule that our ci pipeline will not use

# with key prefix
# a custom prefix is prepended to the versioned prefix
bazel run //test:dev_s3_release_prefix # runs dev rule that our ci pipeline will not use
bazel run //test:ci_s3_release_prefix.ci # runs prod rule that our ci pipeline will use
```

hermez_pipeline_test
-------
Calls HermezAPI to test the validity of the deployment pipeline defined by user PR.
```
bazel run //test:hermez_pipeline
```

Helper Rules
============
Custom rules created to get information in a managaged monorepo.

find_owner
--------
Given a target's label, the rule reports back the most frequent git authors
to the BUILD file that defines the specified target.
