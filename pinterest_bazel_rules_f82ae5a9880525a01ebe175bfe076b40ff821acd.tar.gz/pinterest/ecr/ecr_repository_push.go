package main

import (
	"flag"
	"fmt"
	"os"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/awserr"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/ecr"
)

func main() {
	repository := flag.String("repository", "", "ECR Repository")
	region := flag.String("region", "us-east-1", "ECR Region")
	flag.Parse()

	// Require all flags
	if *repository == "" || *region == "" {
		flag.PrintDefaults()
		os.Exit(1)
	}

	sess := session.Must(session.NewSession(&aws.Config{Region: aws.String(*region)}))
	svc := ecr.New(sess)
	repository_pushParams := &ecr.CreateRepositoryInput{
		RepositoryName: aws.String(*repository),
		ImageTagMutability: aws.String(ecr.ImageTagMutabilityImmutable),
	}
	
	fmt.Printf("Creating %s...\n", *repository)
	_, err := svc.CreateRepository(repository_pushParams)
	if err != nil {
		if aerr, ok := err.(awserr.Error); ok {
			switch aerr.Code() {
			case ecr.ErrCodeRepositoryAlreadyExistsException:
				fmt.Printf("%s already exists\n", *repository)
				os.Exit(0)
			default:
				fmt.Println(aerr.Error())
				os.Exit(1)
			}
		}
	}

	fmt.Printf("Created %s\n", *repository)
}
