# Release Notes

## 0.1.2
- commit: `475dcda3efcfc56d4867a4539023c7a0560afb06`
- fixes flink_release rule and adds hologram_auth dependency

## 0.1.1
- commit: `5d1f809dc6c9aec712b3b1f3dc931ad7671d3838`
- s3_release macro adds username to object key if no key prefix provided

## 0.1.0
- commit: `dcb81a6a3a279c0bba44084c05cd5e001e57fa1d`
- first versioned release of pinterest-rules
- s3_push rule adds commit to object key
