package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"io/ioutil"
	"net/http"
	"strconv"
	"os"

	"pinterest.com/bazel-rules/pinterest/stamp/parse"
)

type JsonData struct {
	Query string `json:"query"`
}

func main() {
	src := flag.String("src", "", "Source File")
	stampFile := flag.String("stamp_file", "", "Source File")
	flag.Parse()

	if *src == "" || *stampFile == "" {
		flag.PrintDefaults()
		os.Exit(1)
	}

	values := parse.StampFile(*stampFile)
	checkForRequiredStampValues([]string{
		"GIT_REPO_CALLSIGN",
		"GIT_COMMIT_SHA",
		"GIT_COMMIT_DATE",
	}, values)

	repo := values["GIT_REPO_CALLSIGN"]
	commitSHA := values["GIT_COMMIT_SHA"]
	commitDateStr := values["GIT_COMMIT_DATE"]
	commitDate, err := strconv.Atoi(commitDateStr)
	var env string
	var ok bool
	if env, ok = values["ENV"]; !ok {
		env = "dev"
	}

	if err != nil {
		fmt.Printf("Failed to convert GIT_COMMIT_DATE to an integer: %s", err)
		os.Exit(1)
	}

	fmt.Printf("Repo: %s, Commit SHA: %s, timestamp: %d, env: %s\n", repo, commitSHA, commitDate, env)

	content, err := ioutil.ReadFile(*src)
	if err != nil {
		fmt.Println("Error reading file ", *src, "\n", err)
		os.Exit(1)
	}

	// "isProd" is used to differentiate pr and land pipelines.
	url := "http://localhost:19193/hermez-api/api/query"  // Hit the envoy port on each Jenkins host with the Hermez filter + Hermez path.
	isProd := false
	if env == "land" {
		isProd = true
	} else if env == "dev" {
		url = "http://localhost:19193/api/query"
	}

	escapedStr, _ := json.Marshal(string(content))
	commitSha, _ := json.Marshal(commitSHA)
	commitRepo, _ := json.Marshal(repo)
	commitSrc, _ := json.Marshal(*src)

	s := fmt.Sprintf("mutation { createDeploymentPipeline ( config : %s, commitSha: %s, commitDate: %d, repo: %s, src: %s, isProduction: %t)}",
		escapedStr, commitSha, commitDate, commitRepo, commitSrc, isProd)
	data := JsonData {  s}
	jsonBytes, _ := json.Marshal(data)

	req, err := http.NewRequest("POST", url, bytes.NewBuffer(jsonBytes))
	if err != nil {
		fmt.Println("Failed to create POST request to ", url, " with error: ", err)
		os.Exit(1)
	}
	req.Header.Set("Content-Type", "application/json")
	if env != "pr" && env != "land" {
		req.Host = "hermez-testing.pinadmin.com"
	}
	client := &http.Client{}
	resp, err := client.Do(req)
	if err != nil {
		fmt.Println("POST request to ", url, " failed: ", err)
		os.Exit(1)
	}
	defer resp.Body.Close()

	fmt.Println("Received response from Hermez server ", url, " for request ", data)
}

func checkForRequiredStampValues(keys []string, stampValues map[string]string) {
	for _, key := range keys {
		if _, ok := stampValues[key]; !ok {
			fmt.Printf("Missing required stamp value: %q", key)
			os.Exit(1)
		}
	}
}
