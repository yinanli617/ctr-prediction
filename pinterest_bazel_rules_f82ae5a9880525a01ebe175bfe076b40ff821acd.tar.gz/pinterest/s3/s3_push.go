package main

import (
	"flag"
	"fmt"
	"os"

	"github.com/aws/aws-sdk-go/aws"
	"github.com/aws/aws-sdk-go/aws/session"
	"github.com/aws/aws-sdk-go/service/s3/s3manager"
)

func main() {
	src := flag.String("src", "", "Source File")
	region := flag.String("region", "us-east-1", "Destination S3 Region")
	bucket := flag.String("bucket", "", "Destination S3 Bucket")
	key := flag.String("key", "", "Destintation S3 Key")
	flag.Parse()

	// Require all flags
	if *src == "" || *region == "" || *bucket == "" || *key == "" {
		flag.PrintDefaults()
		os.Exit(1)
	}

	file, err := os.Open(*src)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}
	defer file.Close()

	sess := session.Must(session.NewSession(&aws.Config{Region: aws.String(*region)}))
	uploader := s3manager.NewUploader(sess)
	upParams := &s3manager.UploadInput{
		Bucket: aws.String(*bucket),
		Key:    aws.String(*key),
		Body:   file,
	}

	fmt.Printf("Uploading %s...\n", *src)
	_, err = uploader.Upload(upParams)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}

	fmt.Printf("Uploaded to s3://%s/%s\n", *bucket, *key)
}
