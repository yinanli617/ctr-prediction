package main

import (
	"bytes"
	"encoding/json"
	"flag"
	"fmt"
	"net/http"
	"os"
	"strconv"

	"pinterest.com/bazel-rules/pinterest/stamp/parse"
)

type build struct {
	ID             string `json:"id,omitempty"`
	Name           string `json:"name"`
	ArtifactURL    string `json:"artifactUrl"`
	Repo           string `json:"repo"`
	Branch         string `json:"branch"`
	CommitSHA      string `json:"commit"`
	CommitSHAShort string `json:"commitShort"`
	CommitDate     int    `json:"commitDate"`
	PublishInfo    string `json:"publishInfo,omitempty"`
	PublishDate    int    `json:"publishDate,omitempty"`
	Publisher      string `json:"publisher,omitempty"`
}

const teletraanURL = "https://teletraan.pinadmin.com/v1/builds"
const deployURL = "https://deploy.pinadmin.com/builds"

func main() {
	token := flag.String("token", "", "Teletraan API Token")
	name := flag.String("name", "", "Build name")
	artifactURL := flag.String("artifact_url", "", "Artifact URL")
	stampFile := flag.String("stamp_file", "", "bazel volatile status file with stamp values")
	flag.Parse()

	if *token == "" || *name == "" || *artifactURL == "" {
		flag.PrintDefaults()
		os.Exit(1)
	}

	values := parse.StampFile(*stampFile)
	checkForRequiredStampValues([]string{
		"GIT_REPO_CALLSIGN",
		"GIT_BRANCH",
		"GIT_COMMIT_SHA",
		"GIT_COMMIT_DATE",
		"PUBLISHER_INFO",
	}, values)

	commitDateStr := values["GIT_COMMIT_DATE"]
	commitDate, err := strconv.Atoi(commitDateStr)
	if err != nil {
		fmt.Printf("Failed to convert GIT_COMMIT_DATE to an integer: %s", err)
		os.Exit(1)
	}

	reqBuild := build{
		Name:        *name,
		ArtifactURL: *artifactURL,
		Repo:        values["GIT_REPO_CALLSIGN"],
		Branch:      values["GIT_BRANCH"],
		CommitSHA:   values["GIT_COMMIT_SHA"],
		CommitDate:  commitDate * 1000,
		PublishInfo: values["PUBLISHER_INFO"],
	}
	reqBody, err := json.Marshal(reqBuild)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}

	client := &http.Client{}
	req, err := http.NewRequest("POST", teletraanURL, bytes.NewBuffer(reqBody))
	if err != nil {
		fmt.Printf("Failed to create POST request: %s\n", err)
		os.Exit(1)
	}
	req.Header.Set("Authorization", fmt.Sprintf("token %s", *token))
	req.Header.Add("Accept", "application/json")
	req.Header.Add("Content-Type", "application/json")
	fmt.Printf("Publishing %s...\n", *name)
	resp, err := client.Do(req)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}

	defer resp.Body.Close()
	if resp.StatusCode < 200 || resp.StatusCode > 299 {
		fmt.Printf("HTTP failure: %s\n", http.StatusText(resp.StatusCode))
		os.Exit(1)
	}

	var respBuild build
	err = json.NewDecoder(resp.Body).Decode(&respBuild)
	if err != nil {
		fmt.Println(err)
		os.Exit(1)
	}

	fmt.Printf("Published %s/%s\n", deployURL, respBuild.ID)
}

func checkForRequiredStampValues(keys []string, stampValues map[string]string) {
	for _, key := range keys {
		if _, ok := stampValues[key]; !ok {
			fmt.Printf("Missing required stamp value: %q", key)
			os.Exit(1)
		}
	}
}
