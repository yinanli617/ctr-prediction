package main

import (
	"flag"
	"fmt"
	"io/ioutil"
	"os"
	"strings"

	"pinterest.com/bazel-rules/pinterest/stamp/parse"
)

func main() {
	stampFile := flag.String("stamp_file", "", "bazel volatile status file with stamp values (required)")
	key := flag.String("key", "", "key name in stamp file")
	replaceFile := flag.String("replace_in_file", "", "replaces stamp values in provided filename")
	replaceString := flag.String("replace_in_string", "", "replaces stamp values in provided string")
	flag.Parse()

	// check flag inputs
	if *stampFile == "" {
		flag.PrintDefaults()
	}
	if !fileExists(*stampFile) {
		fmt.Printf("Stamp file does not exist or is a directory: %q", *stampFile)
		os.Exit(1)
	}
	if *key == "" && *replaceFile == "" && *replaceString == "" {
		fmt.Println("Must provide either -key, -replace_in_file, or -replace_in_string")
		flag.PrintDefaults()
		os.Exit(1)
	}

	stampValues := parse.StampFile(*stampFile)

	// print value for given key
	if *key != "" {
		parse.StampValue(*key, stampValues)
		os.Exit(0)
	}

	// replace stamp values in file
	if *replaceFile != "" {
		if !fileExists(*replaceFile) {
			fmt.Printf("file to replace stamp values in does not exist or is a directory: %q", *replaceFile)
			os.Exit(1)
		}

		read, err := ioutil.ReadFile(*replaceFile)
		if err != nil {
			fmt.Printf("failed to read file: %q", *replaceFile)
			os.Exit(1)
		}

		fileContents := string(read)
		for key, value := range stampValues {
			fileContents = strings.ReplaceAll(fileContents, fmt.Sprintf("{%s}", key), value)
		}

		err = ioutil.WriteFile(*replaceFile, []byte(fileContents), 0)
		if err != nil {
			fmt.Printf("error rewriting file with stamp values: %q", *replaceFile)
			os.Exit(1)
		}

		os.Exit(0)
	}

	// replace stamp values in string
	if *replaceString != "" {
		stringContent := string(*replaceString)
		for key, value := range stampValues {
			stringContent = strings.ReplaceAll(stringContent, fmt.Sprintf("{%s}", key), value)
		}

		fmt.Println(stringContent)
	}
}

// checks if given file exists and is not a directory
func fileExists(filename string) bool {
	info, err := os.Stat(filename)
	if os.IsNotExist(err) {
		return false
	}
	return !info.IsDir()
}
