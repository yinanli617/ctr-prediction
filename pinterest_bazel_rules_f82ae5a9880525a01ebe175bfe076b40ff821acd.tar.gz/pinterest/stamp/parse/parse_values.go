package parse

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

// reads the contents of the stamp file and creates
// a map for the values in the file. errors and exists if
// contents of stamp file are not key value pairs
// adds short version of git commit sha if GIT_COMMIT_SHA exists
func StampFile(filename string) map[string]string {
	values := map[string]string{}

	file, err := os.Open(filename)
	if err != nil {
		fmt.Printf("failed to open stamp file %q: %s", err, filename)
		os.Exit(1)
	}
	defer file.Close()

	scanner := bufio.NewScanner(file)
	for scanner.Scan() {
		text := scanner.Text()
		line := strings.Split(text, " ")

		if len(line) != 2 {
			// intentionally panic because workspace_status is not in documentated format
			panic("expected stamp file to contain key and value pairs only")
		}

		key := line[0]
		value := line[1]
		values[key] = value
	}

	if err := scanner.Err(); err != nil {
		fmt.Printf("failed to read stamp file: %s", err)
		os.Exit(1)
	}

	if sha, ok := values["GIT_COMMIT_SHA"]; ok {
		values["GIT_COMMIT_SHA_SHORT"] = sha[0:11]
	}

	return values
}

// prints the value for the givem key
// errors and exits if given key was not found
func StampValue(key string, values map[string]string) {
	if value, ok := values[key]; ok {
		fmt.Println(value)
	} else {
		fmt.Printf("key not found: %q", key)
		os.Exit(1)
	}
}
