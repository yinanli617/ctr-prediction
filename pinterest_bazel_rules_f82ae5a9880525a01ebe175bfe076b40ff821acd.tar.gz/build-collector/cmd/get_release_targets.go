package cmd

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"

	"github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"pinterest.com/bazel-rules/build-collector/cmd/bazel"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
)

type GetReleaseTargetsCmd struct {
	Analyzer   Analyzer
	Collector  Collector
	Dir        string
	OutputFile string
}

func NewGetReleaseTargetsCmd(analyzer Analyzer, collector Collector) GetReleaseTargetsCmd {
	return GetReleaseTargetsCmd{
		Analyzer:  analyzer,
		Collector: collector,
	}
}

func NewGRTCmd() *cobra.Command {
	collector := collect.NewCollector()
	analyzer := bazel.NewAnalyzer()
	grt := NewGetReleaseTargetsCmd(analyzer, collector)

	cmd := &cobra.Command{
		Use:   "get-release-targets",
		Short: "Returns bazel release targets",
		Long:  `Finds the affected bazel release targets based on two git commits and writes them to a JSON file`,
		RunE: func(cmd *cobra.Command, args []string) error {
			return grt.Run()
		},
	}

	flags := cmd.Flags()
	flags.StringVarP(&grt.Dir, "directory", "d", "", "directory to read from (required)")
	flags.StringVarP(&collector.PreviousCommit, "previous-commit", "p", "", "previous commit to compare from (required)")
	flags.StringVarP(&collector.LatestCommit, "latest-commit", "l", "", "latest commit to compare to (required)")
	flags.StringVarP(&grt.OutputFile, "output-file", "o", "release-targets.json", "path to result file of release targets")

	cmd.MarkFlagRequired("directory")
	cmd.MarkFlagRequired("previous-commit")
	cmd.MarkFlagRequired("latest-commit")

	return cmd
}

func (grt *GetReleaseTargetsCmd) Run() error {
	logrus.Infof("verifying directory %q exists...", grt.Dir)
	if _, err := os.Stat(grt.Dir); os.IsNotExist(err) {
		return fmt.Errorf("Failed to find directory %q: %s", grt.Dir, err)
	}

	logrus.Info("collecting modified files...")
	fileCollection, err := grt.Collector.Files(grt.Dir)
	if err != nil {
		return fmt.Errorf("Failed to collect files: %s", err)
	}

	logrus.Info("collecting affected bazel release targets...")
	targets, err := grt.Analyzer.FindReleases(grt.Dir, fileCollection)
	if err != nil {
		return fmt.Errorf("Failed to find releases: %s", err)
	}

	logrus.Info("formatting results to JSON...")
	results := FormatResults(formatReleaseTargets(targets), fileCollection)
	file, err := json.MarshalIndent(results, "", " ")
	if err != nil {
		return fmt.Errorf("Failed to marshall JSON: %s", err)
	}

	logrus.Infof("writing results to %q...", grt.OutputFile)
	if err := ioutil.WriteFile(grt.OutputFile, file, 0644); err != nil {
		return fmt.Errorf("Failed to write JSON file with release target information to %q: %s", grt.OutputFile, err)
	}

	return nil
}

func formatReleaseTargets(targets []string) []Target {
	result := []Target{}
	for _, label := range targets {
		target := Target{Label: label}
		result = append(result, target)
	}

	return result
}
