package bazel_test

import (
	"errors"
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	"github.com/golang/mock/gomock"
	"pinterest.com/bazel-rules/build-collector/cmd/bazel"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
	"pinterest.com/bazel-rules/build-collector/cmd/mocks"
)

var _ = Describe("FindBinaries", func() {
	var (
		mockCtrl   *gomock.Controller
		mockRunner *mocks.MockRunner
		analyzer   *bazel.Analyzer
		collection collect.FileCollection
		dir        string
		err        error
	)

	BeforeEach(func() {
		mockCtrl = gomock.NewController(GinkgoT())
		mockRunner = mocks.NewMockRunner(mockCtrl)
		analyzer = bazel.NewAnalyzer()
		analyzer.Runner = mockRunner

		dir, err = ioutil.TempDir("", "find-test")
		Expect(err).NotTo(HaveOccurred())

		collection = collect.FileCollection{}
	})

	AfterEach(func() {
		mockCtrl.Finish()
		os.RemoveAll(dir)
	})

	Context("When the WORKSPACE file is modified", func() {
		It("collects all the targets", func() {
			collection.WORKSPACE = true
			foundTargets := []string{":some-binary", ":another-binary"}

			mockRunner.EXPECT().SetDir(dir).Times(1)
			mockRunner.EXPECT().RunQuery(
				"let binaries = kind(\".*_binary\", //...) in $binaries except attr(tags, manual, $binaries) except attr(tags, no-ci, $binaries)",
			).Return(foundTargets, nil).Times(1)

			targets, err := analyzer.FindBinaries(dir, collection)
			Expect(err).ToNot(HaveOccurred())
			Expect(targets).To(Equal(foundTargets))
		})
	})

	Context("When BUILD files have been modified", func() {
		It("collects all targets defined in each modified BUILD file", func() {
			collection.BUILDFiles = []string{"BUILD", "some-dir/BUILD"}
			foundTargets := []string{":some-binary", ":another-binary"}
			foundBUILDLabels := []string{"//:BUILD", "//some-dir:BUILD"}

			mockRunner.EXPECT().SetDir(dir).Times(1)
			mockRunner.EXPECT().RunQuery("set(BUILD some-dir/BUILD)").Return(foundBUILDLabels, nil).Times(1)
			mockRunner.EXPECT().RunQuery(
				"let binaries = kind(\".*_binary\", rdeps(//..., set(//:all //some-dir:all))) in $binaries except attr(tags, manual, $binaries) except attr(tags, no-ci, $binaries)",
			).Return(foundTargets, nil).Times(1)

			targets, err := analyzer.FindBinaries(dir, collection)
			Expect(err).ToNot(HaveOccurred())
			Expect(targets).To(Equal(foundTargets))
		})
	})

	Context("When there are extension files", func() {
		It("collects all BUILD files that load the extensions and collects targets defined in each BUILD file", func() {
			collection.ExtensionFiles = []string{"ext.bzl", "another_ext.bzl"}
			foundTargets := []string{":some-binary", ":another-binary"}

			mockRunner.EXPECT().SetDir(dir).Times(1)
			mockRunner.EXPECT().RunSkyQuery("rbuildfiles(ext.bzl,another_ext.bzl)").Return([]string{"//some-dir:BUILD.bazel"}, nil).Times(1)
			mockRunner.EXPECT().RunQuery(
				"let binaries = kind(\".*_binary\", rdeps(//..., set(//some-dir:all))) in $binaries except attr(tags, manual, $binaries) except attr(tags, no-ci, $binaries)",
			).Return(foundTargets, nil).Times(1)

			targets, err := analyzer.FindBinaries(dir, collection)
			Expect(err).ToNot(HaveOccurred())
			Expect(targets).To(Equal(foundTargets))
		})
	})

	Context("When there are deleted files", func() {
		var (
			deletedFile string
			buildPath1  string
			buildPath2  string
		)

		BeforeEach(func() {
			directories := filepath.Join(dir, "some-dir", "another-dir")
			err := os.MkdirAll(directories, 0755)
			Expect(err).NotTo(HaveOccurred())

			buildPath1 = filepath.Join(directories, "BUILD")
			buildPath2 = filepath.Join(dir, "some-dir", "BUILD.bazel")
			contents := []byte(`some BUILD contents`)

			err = ioutil.WriteFile(buildPath1, contents, 0644)
			Expect(err).NotTo(HaveOccurred())

			err = ioutil.WriteFile(buildPath2, contents, 0644)
			Expect(err).NotTo(HaveOccurred())

			deletedFile = filepath.Join(dir, "some-dir", "another-dir", "no-more.sh")
		})

		It("collects all BUILD files in parent directories of the deleted file and collects targets defined in each BUILD file", func() {
			collection.DeletedFiles = []string{deletedFile}
			foundTargets := []string{":some-binary"}

			mockRunner.EXPECT().SetDir(dir).Times(1)
			mockRunner.EXPECT().RunQuery(
				fmt.Sprintf("set(%s/some-dir/another-dir/BUILD %s/some-dir/BUILD.bazel)", dir, dir),
			).Return([]string{"//tmp/123/some-dir/another-dir:BUILD", "//tmp/123/some-dir:all"}, nil).Times(1)

			mockRunner.EXPECT().RunQuery(
				"let binaries = kind(\".*_binary\", rdeps(//..., set(//tmp/123/some-dir/another-dir:all //tmp/123/some-dir:all))) in $binaries except attr(tags, manual, $binaries) except attr(tags, no-ci, $binaries)",
			).Return(foundTargets, nil).Times(1)

			targets, err := analyzer.FindBinaries(dir, collection)
			Expect(err).ToNot(HaveOccurred())
			Expect(targets).To(Equal(foundTargets))
		})
	})

	Context("When there are source files", func() {
		It("collects are targets dependedent on each source file", func() {
			collection.SourceFiles = []string{"some-file.sh"}
			foundTargets := []string{":some-binary", ":another-binary"}

			mockRunner.EXPECT().SetDir(dir).Times(1)
			mockRunner.EXPECT().RunQuery(
				"let binaries = kind(\".*_binary\", rdeps(//..., set(some-file.sh))) in $binaries except attr(tags, manual, $binaries) except attr(tags, no-ci, $binaries)",
			).Return(foundTargets, nil).Times(1)

			targets, err := analyzer.FindBinaries(dir, collection)
			Expect(err).ToNot(HaveOccurred())
			Expect(targets).To(Equal(foundTargets))
		})
	})

	Context("Error Cases", func() {
		Context("When querying for all targets fails ", func() {
			It("returns an error", func() {
				collection.WORKSPACE = true

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, errors.New("nope")).Times(1)

				_, err := analyzer.FindBinaries(dir, collection)
				Expect(err).To(MatchError("failed to get all build targets: nope"))
			})
		})

		Context("When querying for BUILD labels fails ", func() {
			It("returns an error", func() {
				collection.BUILDFiles = []string{"BUILD"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, errors.New("nope")).Times(1)

				_, err := analyzer.FindBinaries(dir, collection)
				Expect(err).To(MatchError("failed to analyze BUILD files: failed getting BUILD labels: nope"))
			})
		})

		Context("When querying for labels dependent on extension files fails ", func() {
			It("returns an error", func() {
				collection.ExtensionFiles = []string{"ext.bzl"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunSkyQuery(gomock.Any()).Return(nil, errors.New("nope")).Times(1)

				_, err := analyzer.FindBinaries(dir, collection)
				Expect(err).To(MatchError("failed to analyze extension files: failed getting BUILD labels: nope"))
			})
		})

		Context("When querying for a deleted file's targets fail ", func() {
			It("returns an error", func() {
				collection.DeletedFiles = []string{"no-more.sh"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, errors.New("nope")).Times(1)

				_, err := analyzer.FindBinaries(dir, collection)
				Expect(err.Error()).To(ContainSubstring("failed to analyze deleted files"))
			})
		})

		Context("When querying for test targets fails", func() {
			It("returns an error", func() {
				collection.SourceFiles = []string{"some-file.sh"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, errors.New("nope")).Times(1)

				_, err := analyzer.FindBinaries(dir, collection)
				Expect(err.Error()).To(ContainSubstring("failed to query build targets: nope"))
			})
		})

		Context("When querying for timeouts fails", func() {
			It("returns an error", func() {
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, errors.New("nope")).Times(1)

				_, err := analyzer.GetTimeouts([]string{":some-target"})
				Expect(err).To(MatchError("failed to get timeouts for test targets: nope"))
			})
		})
	})
})
