package bazel

import (
	"fmt"
	"sort"

	"github.com/sirupsen/logrus"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
	"pinterest.com/bazel-rules/build-collector/cmd/run"
)

const ALL = "//..."

var TimeoutOptions = map[string]int{
	"short":    1,
	"moderate": 5,
	"long":     15,
	"eternal":  60,
}

//go:generate mockgen -destination=../mocks/run.go -package=mocks pinterest.com/bazel-rules/build-collector/cmd/bazel Runner
type Runner interface {
	SetDir(string)
	Run(string, ...string) ([]string, error)
	RunQuery(string) ([]string, error)
	RunOrderQuery(string) ([]string, error)
	RunSkyQuery(string) ([]string, error)
}

type Analyzer struct {
	Runner Runner
}

func NewAnalyzer() *Analyzer {
	return &Analyzer{
		Runner: run.NewCmdRunner(),
	}
}

func (a Analyzer) FindTests(dir string, fileCollection collect.FileCollection) (map[string]int, error) {
	a.Runner.SetDir(dir)

	if fileCollection.WORKSPACE {
		query := ConstructTestQuery(ALL)
		logrus.Info("WORKSPACE file changed, querying all test targets...")
		logrus.Debugf("bazel query: [ %q ]", query)

		allTestTargets, err := a.Runner.RunQuery(query)
		if err != nil {
			return nil, fmt.Errorf("failed to get all test targets: %s", err)
		}

		logrus.Info("querying test timeouts...")
		return a.GetTimeouts(allTestTargets)
	}

	foundLabels := []string{}
	if len(fileCollection.BUILDFiles) > 0 {
		labels, err := a.AnalyzeBUILDFiles(fileCollection.BUILDFiles)
		if err != nil {
			return nil, fmt.Errorf("failed to analyze BUILD files: %s", err)
		}
		foundLabels = append(foundLabels, labels...)
	}

	if len(fileCollection.ExtensionFiles) > 0 {
		labels, err := a.AnalyzeExtensionFiles(fileCollection.ExtensionFiles)
		if err != nil {
			return nil, fmt.Errorf("failed to analyze extension files: %s", err)
		}
		foundLabels = append(foundLabels, labels...)
	}

	if len(fileCollection.DeletedFiles) > 0 {
		labels, err := a.AnalyzeDeletedFiles(fileCollection.DeletedFiles)
		if err != nil {
			return nil, fmt.Errorf("failed to analyze deleted files: %s", err)
		}
		foundLabels = append(foundLabels, labels...)
	}

	if len(fileCollection.SourceFiles) > 0 {
		foundLabels = append(foundLabels, fileCollection.SourceFiles...)
	}

	targets, err := a.QueryTestTargets(foundLabels)
	if err != nil {
		return nil, fmt.Errorf("failed to query test targets: %s", err)
	}

	logrus.Info("querying test timeouts...")
	return a.GetTimeouts(targets)
}

func (a Analyzer) GetTimeouts(targets []string) (map[string]int, error) {
	result := map[string]int{}

	sortedTimeoutNames := []string{}
	for names := range TimeoutOptions {
		sortedTimeoutNames = append(sortedTimeoutNames, names)
	}
	sort.Strings(sortedTimeoutNames)

	for _, timeoutName := range sortedTimeoutNames {
		targetSet := Set{Files: targets}
		chunks := targetSet.Chunks()

		for _, chunk := range chunks {
			attr := Attr{
				Name:  "timeout",
				Input: timeoutName,
				Scope: chunk.String(),
			}

			labels, err := a.Runner.RunQuery(attr.String())
			if err != nil {
				return nil, fmt.Errorf("failed to get timeouts for test targets: %s", err)
			}

			for _, label := range labels {
				result[label] = TimeoutOptions[timeoutName]
			}
		}
	}
	return result, nil
}

func (a Analyzer) QueryTestTargets(files []string) ([]string, error) {
	var result []string

	labelSet := Set{Files: files}
	chunks := labelSet.Chunks()

	for _, chunk := range chunks {
		rdeps := Rdeps{
			Universe: ALL,
			Scope:    chunk.String(),
		}

		query := ConstructTestQuery(rdeps.String())
		logrus.Info("querying test targets...")
		logrus.Debugf("bazel query: [ %q ]", query)

		targets, err := a.Runner.RunQuery(query)
		if err != nil {
			return nil, err
		}

		result = append(result, targets...)
	}

	return result, nil
}

func ConstructTestQuery(scope string) string {
	testsQuery := Tests{Scope: scope}
	tests := Let{
		Name:  "tests",
		Value: testsQuery.String(),
	}

	query := tests.Var()
	manualTags := Attr{Name: "tags", Input: "manual", Scope: tests.Var()}
	noCITags := Attr{Name: "tags", Input: "no-ci", Scope: tests.Var()}
	flakyTags := Attr{Name: "tags", Input: "flaky-test-*", Scope: tests.Var()}
	query = appendExceptions(query, []Attr{manualTags, noCITags, flakyTags})
	query = prependLet(query, tests)

	return query
}
