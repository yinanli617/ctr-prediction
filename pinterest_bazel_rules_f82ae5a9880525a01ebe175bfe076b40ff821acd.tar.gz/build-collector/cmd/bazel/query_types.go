package bazel

import (
	"fmt"
	"strings"
)

const MAX_TARGETS = 900

type Attr struct {
	Name  string
	Input string
	Scope string
}

type Deps struct {
	Scope string
}

type RbuildFiles struct {
	Scope string
}

type Rdeps struct {
	Universe string
	Scope    string
}

type Set struct {
	Files []string
}

type Kind struct {
	Pattern string
	Scope   string
}

type Tests struct {
	Scope string
}

type Let struct {
	Name  string
	Value string
}

func (a *Attr) String() string {
	return fmt.Sprintf("attr(%s, %s, %s)", a.Name, a.Input, a.Scope)
}

func (r *RbuildFiles) String() string {
	return fmt.Sprintf("rbuildfiles(%s)", r.Scope)
}

func (d *Deps) String() string {
	return fmt.Sprintf("deps(%s)", d.Scope)
}

func (r *Rdeps) String() string {
	return fmt.Sprintf("rdeps(%s, %s)", r.Universe, r.Scope)
}

func (s *Set) Chunks() []Set {
	var result []Set

	fileChunks := CreateChunks(s.Files, MAX_TARGETS)
	for _, chunk := range fileChunks {
		result = append(result, Set{Files: chunk})
	}

	return result
}

func (s *Set) String() string {
	return fmt.Sprintf("set(%s)", strings.Join(s.Files, " "))
}

func (k *Kind) String() string {
	return fmt.Sprintf("kind(%q, %s)", k.Pattern, k.Scope)
}

func (t *Tests) String() string {
	return fmt.Sprintf("tests(%s)", t.Scope)
}

func (l *Let) String() string {
	return fmt.Sprintf("let %s = %s", l.Name, l.Value)
}

func (l *Let) Var() string {
	return fmt.Sprintf("$%s", l.Name)
}

func CreateChunks(files []string, size int) [][]string {
	var chunks [][]string

	for i := 0; i < len(files); i += size {
		end := i + size

		if end > len(files) {
			end = len(files)
		}

		chunks = append(chunks, files[i:end])
	}

	return chunks
}

func prependLet(queryStr string, let Let) string {
	query := let.String()
	query += " in "
	query += queryStr

	return query
}

func appendExceptions(queryStr string, attrs []Attr) string {
	for _, a := range attrs {
		queryStr += " except "
		queryStr += a.String()
	}
	return queryStr
}
