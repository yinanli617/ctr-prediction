package bazel

import (
	"fmt"

	"github.com/sirupsen/logrus"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
)

func (a Analyzer) FindBinaries(dir string, fileCollection collect.FileCollection) ([]string, error) {
	a.Runner.SetDir(dir)

	if fileCollection.WORKSPACE {
		query := ConstructBinaryQuery(ALL)
		logrus.Info("WORKSPACE file changed, querying all build targets...")
		logrus.Debugf("bazel query: [ %q ]", query)

		allBinaryTargets, err := a.Runner.RunQuery(query)
		if err != nil {
			return nil, fmt.Errorf("failed to get all build targets: %s", err)
		}

		return allBinaryTargets, nil
	}

	foundLabels := []string{}
	if len(fileCollection.BUILDFiles) > 0 {
		labels, err := a.AnalyzeBUILDFiles(fileCollection.BUILDFiles)
		if err != nil {
			return nil, fmt.Errorf("failed to analyze BUILD files: %s", err)
		}
		foundLabels = append(foundLabels, labels...)
	}

	if len(fileCollection.ExtensionFiles) > 0 {
		labels, err := a.AnalyzeExtensionFiles(fileCollection.ExtensionFiles)
		if err != nil {
			return nil, fmt.Errorf("failed to analyze extension files: %s", err)
		}
		foundLabels = append(foundLabels, labels...)
	}

	if len(fileCollection.DeletedFiles) > 0 {
		labels, err := a.AnalyzeDeletedFiles(fileCollection.DeletedFiles)
		if err != nil {
			return nil, fmt.Errorf("failed to analyze deleted files: %s", err)
		}
		foundLabels = append(foundLabels, labels...)
	}

	if len(fileCollection.SourceFiles) > 0 {
		foundLabels = append(foundLabels, fileCollection.SourceFiles...)
	}

	targets, err := a.QueryBinaryTargets(foundLabels)
	if err != nil {
		return nil, fmt.Errorf("failed to query build targets: %s", err)
	}

	return targets, nil
}

func ConstructBinaryQuery(scope string) string {
	kindQuery := Kind{
		Pattern: ".*_binary",
		Scope:   scope,
	}
	binaries := Let{
		Name:  "binaries",
		Value: kindQuery.String(),
	}

	query := binaries.Var()
	manualTags := Attr{Name: "tags", Input: "manual", Scope: binaries.Var()}
	noCITags := Attr{Name: "tags", Input: "no-ci", Scope: binaries.Var()}
	query = appendExceptions(query, []Attr{manualTags, noCITags})
	query = prependLet(query, binaries)

	return query
}

func (a Analyzer) QueryBinaryTargets(files []string) ([]string, error) {
	var result []string

	labelSet := Set{Files: files}
	chunks := labelSet.Chunks()

	for _, chunk := range chunks {
		rdeps := Rdeps{
			Universe: ALL,
			Scope:    chunk.String(),
		}

		query := ConstructBinaryQuery(rdeps.String())
		logrus.Info("querying build targets...")
		logrus.Debugf("bazel query: [ %q ]", query)

		targets, err := a.Runner.RunQuery(query)
		if err != nil {
			return nil, err
		}

		result = append(result, targets...)
	}

	return result, nil
}
