package bazel_test

import (
	"testing"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"
)

func TestBazel(t *testing.T) {
	RegisterFailHandler(Fail)
	RunSpecs(t, "Bazel Unit Test Suite")
}
