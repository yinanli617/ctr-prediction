package bazel_test

import (
	"errors"
	"fmt"
	"io/ioutil"
	"os"
	"path/filepath"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	"github.com/golang/mock/gomock"
	"pinterest.com/bazel-rules/build-collector/cmd/bazel"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
	"pinterest.com/bazel-rules/build-collector/cmd/mocks"
)

var _ = Describe("Query Release Targets", func() {
	var (
		mockCtrl   *gomock.Controller
		mockRunner *mocks.MockRunner
		analyzer   *bazel.Analyzer
		collection collect.FileCollection
		dir        string
		err        error
	)

	BeforeEach(func() {
		mockCtrl = gomock.NewController(GinkgoT())
		mockRunner = mocks.NewMockRunner(mockCtrl)
		analyzer = bazel.NewAnalyzer()
		analyzer.Runner = mockRunner

		dir, err = ioutil.TempDir("", "find-test")
		Expect(err).NotTo(HaveOccurred())

		collection = collect.FileCollection{}
	})

	AfterEach(func() {
		mockCtrl.Finish()
		os.RemoveAll(dir)
	})

	Context("FindReleases", func() {
		Context("When the WORKSPACE file is modified", func() {
			It("collects all the artifact_ci_release targets", func() {
				collection.WORKSPACE = true
				foundReleaseTargets := []string{":release_target", "//dir:release_target"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(
					"let releases = kind(\"artifact_ci_release\", //...) in $releases except attr(tags, no-ci, $releases)",
				).Return(foundReleaseTargets, nil).Times(1)

				releaseTargets, err := analyzer.FindReleases(dir, collection)
				Expect(err).ToNot(HaveOccurred())
				Expect(releaseTargets).To(ContainElement(foundReleaseTargets[0]))
				Expect(releaseTargets).To(ContainElement(foundReleaseTargets[1]))
			})
		})

		Context("When BUILD files have been modified", func() {
			It("collects all the targets definied in each modfieid BUILD file", func() {
				collection.BUILDFiles = []string{"BUILD", "some-dir/BUILD"}
				foundBUILDLabels := []string{"//:BUILD", "//some-dir:BUILD"}
				foundReleaseTargets := []string{":release_target", "//some-dir:release_target"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery("set(BUILD some-dir/BUILD)").Return(foundBUILDLabels, nil).Times(1)
				mockRunner.EXPECT().RunQuery(
					"let releases = kind(\"artifact_ci_release\", rdeps(//..., set(//:all //some-dir:all))) in $releases except attr(tags, no-ci, $releases)",
				).Return(foundReleaseTargets, nil).Times(1)

				releaseTargets, err := analyzer.FindReleases(dir, collection)
				Expect(err).ToNot(HaveOccurred())
				Expect(releaseTargets).To(ContainElement(foundReleaseTargets[0]))
				Expect(releaseTargets).To(ContainElement(foundReleaseTargets[1]))
			})
		})

		Context("When there are extension files", func() {
			It("collects all BUILD files that load the extensions and collects targets defined in each BUILD file", func() {
				collection.ExtensionFiles = []string{"ext.bzl", "another_ext.bzl"}
				foundReleaseTargets := []string{":release_target", "//some-dir:release_target"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunSkyQuery("rbuildfiles(ext.bzl,another_ext.bzl)").Return([]string{"//some-dir:BUILD.bazel"}, nil).Times(1)
				mockRunner.EXPECT().RunQuery(
					"let releases = kind(\"artifact_ci_release\", rdeps(//..., set(//some-dir:all))) in $releases except attr(tags, no-ci, $releases)",
				).Return(foundReleaseTargets, nil).Times(1)

				releaseTargets, err := analyzer.FindReleases(dir, collection)
				Expect(err).ToNot(HaveOccurred())
				Expect(releaseTargets).To(ContainElement(foundReleaseTargets[0]))
				Expect(releaseTargets).To(ContainElement(foundReleaseTargets[1]))
			})
		})

		Context("When there are deleted files", func() {
			var (
				deletedFile string
				buildPath1  string
				buildPath2  string
			)

			BeforeEach(func() {
				directories := filepath.Join(dir, "some-dir", "another-dir")
				err := os.MkdirAll(directories, 0755)
				Expect(err).NotTo(HaveOccurred())

				buildPath1 = filepath.Join(directories, "BUILD")
				buildPath2 = filepath.Join(dir, "some-dir", "BUILD.bazel")
				contents := []byte(`some BUILD contents`)

				err = ioutil.WriteFile(buildPath1, contents, 0644)
				Expect(err).NotTo(HaveOccurred())

				err = ioutil.WriteFile(buildPath2, contents, 0644)
				Expect(err).NotTo(HaveOccurred())

				deletedFile = filepath.Join(dir, "some-dir", "another-dir", "no-more.sh")
			})

			It("collects all BUILD files in parent directories of the deleted file and collects targets defined in each BUILD file", func() {
				collection.DeletedFiles = []string{deletedFile}
				foundReleaseTargets := []string{":release_target", "//some-dir:release_target"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(
					fmt.Sprintf("set(%s/some-dir/another-dir/BUILD %s/some-dir/BUILD.bazel)", dir, dir),
				).Return([]string{"//tmp/123/some-dir/another-dir:BUILD", "//tmp/123/some-dir:all"}, nil).Times(1)

				mockRunner.EXPECT().RunQuery(
					"let releases = kind(\"artifact_ci_release\", rdeps(//..., set(//tmp/123/some-dir/another-dir:all //tmp/123/some-dir:all))) in $releases except attr(tags, no-ci, $releases)",
				).Return(foundReleaseTargets, nil).Times(1)

				releaseTargets, err := analyzer.FindReleases(dir, collection)
				Expect(err).ToNot(HaveOccurred())
				Expect(releaseTargets).To(ContainElement(foundReleaseTargets[0]))
				Expect(releaseTargets).To(ContainElement(foundReleaseTargets[1]))
			})
		})

		Context("When there are source files", func() {
			It("collects the targets dependedent on each source file", func() {
				collection.SourceFiles = []string{"some-file.sh"}
				foundReleaseTargets := []string{":release_target", "//some-dir:release_target"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(
					"let releases = kind(\"artifact_ci_release\", rdeps(//..., set(some-file.sh))) in $releases except attr(tags, no-ci, $releases)",
				).Return(foundReleaseTargets, nil).Times(1)

				releaseTargets, err := analyzer.FindReleases(dir, collection)
				Expect(err).ToNot(HaveOccurred())
				Expect(releaseTargets).To(ContainElement(foundReleaseTargets[0]))
				Expect(releaseTargets).To(ContainElement(foundReleaseTargets[1]))
			})
		})
	})

	Context("Error Cases", func() {
		Context("When querying for all targets fails ", func() {
			It("returns an error", func() {
				collection.WORKSPACE = true

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, errors.New("nope")).Times(1)

				_, err := analyzer.FindReleases(dir, collection)
				Expect(err).To(MatchError("failed to get all release targets: nope"))
			})
		})

		Context("When querying for BUILD labels fails ", func() {
			It("returns an error", func() {
				collection.BUILDFiles = []string{"BUILD"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, errors.New("nope")).Times(1)

				_, err := analyzer.FindReleases(dir, collection)
				Expect(err).To(MatchError("failed to analyze BUILD files: failed getting BUILD labels: nope"))
			})
		})

		Context("When querying for labels dependent on extension files fails ", func() {
			It("returns an error", func() {
				collection.ExtensionFiles = []string{"ext.bzl"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunSkyQuery(gomock.Any()).Return(nil, errors.New("nope")).Times(1)

				_, err := analyzer.FindReleases(dir, collection)
				Expect(err).To(MatchError("failed to analyze extension files: failed getting BUILD labels: nope"))
			})
		})

		Context("When querying for a deleted file's targets fail ", func() {
			It("returns an error", func() {
				collection.DeletedFiles = []string{"no-more.sh"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, errors.New("nope")).Times(1)

				_, err := analyzer.FindReleases(dir, collection)
				Expect(err.Error()).To(ContainSubstring("failed to analyze deleted files"))
			})
		})

		Context("When querying for release targets fails", func() {
			It("returns an error", func() {
				collection.SourceFiles = []string{"some-file.sh"}

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, errors.New("nope")).Times(1)

				_, err := analyzer.FindReleases(dir, collection)
				Expect(err.Error()).To(ContainSubstring("failed to query release targets: nope"))
			})
		})
	})
})
