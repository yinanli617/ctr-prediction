package bazel_test

import (
	"strings"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	"pinterest.com/bazel-rules/build-collector/cmd/bazel"
)

var _ = Describe("Query Types", func() {
	Context("Set", func() {
		Context("Chunks", func() {
			It("retuns a list of sets", func() {
				set := bazel.Set{Files: []string{"some-file"}}

				chunks := set.Chunks()
				Expect(len(chunks)).To(Equal(1))
				Expect(chunks).To(ContainElement(set))
			})

			Context("When the files are above the max amount", func() {
				It("returns multiple chunks", func() {
					str := strings.Repeat("some-file ", 1600)
					files := strings.Split(str, " ")
					set := bazel.Set{Files: files}

					chunks := set.Chunks()
					Expect(len(chunks)).To(Equal(2))
				})
			})
		})
	})

	Context("CreateChunks", func() {
		It("it divides the given list of files into chunks of the specified size", func() {
			files := []string{"some-file", "other-file", "another-file"}

			chunks := bazel.CreateChunks(files, 2)
			Expect(len(chunks)).To(Equal(2))
			Expect(chunks).To(ContainElement([]string{"some-file", "other-file"}))
			Expect(chunks).To(ContainElement([]string{"another-file"}))
		})
	})
})
