package bazel

import (
	"fmt"
	"github.com/sirupsen/logrus"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
)

func (a Analyzer) FindReleases(dir string, fileCollection collect.FileCollection) ([]string, error) {
	a.Runner.SetDir(dir)

	// find all release targets when "WORKSPACE" file is changed
	if fileCollection.WORKSPACE {
		query := ConstructReleaseQuery(ALL)

		logrus.Info("WORKSPACE file changed, querying all release targets...")
		logrus.Debugf("bazel query: [ %q ]", query)
		releaseTargets, err := a.Runner.RunQuery(query)
		if err != nil {
			return nil, fmt.Errorf("failed to get all release targets: %s", err)
		}

		return releaseTargets, nil
	}

	// find minimal set of release targets for all other file changes
	foundLabels := []string{}
	if len(fileCollection.BUILDFiles) > 0 {
		labels, err := a.AnalyzeBUILDFiles(fileCollection.BUILDFiles)
		if err != nil {
			return nil, fmt.Errorf("failed to analyze BUILD files: %s", err)
		}
		foundLabels = append(foundLabels, labels...)
	}

	if len(fileCollection.ExtensionFiles) > 0 {
		labels, err := a.AnalyzeExtensionFiles(fileCollection.ExtensionFiles)
		if err != nil {
			return nil, fmt.Errorf("failed to analyze extension files: %s", err)
		}
		foundLabels = append(foundLabels, labels...)
	}
	
	if len(fileCollection.DeletedFiles) > 0 {
		labels, err := a.AnalyzeDeletedFiles(fileCollection.DeletedFiles)
		if err != nil {
			return nil, fmt.Errorf("failed to analyze deleted files: %s", err)
		}
		foundLabels = append(foundLabels, labels...)
	}

	if len(fileCollection.SourceFiles) > 0 {
		foundLabels = append(foundLabels, fileCollection.SourceFiles...)
	}
	
	releaseTargets, err := a.QueryReleases(foundLabels)
	if err != nil {
		return nil, fmt.Errorf("failed to query release targets: %s", err)
	}

	return releaseTargets, nil
}

func (a Analyzer) QueryReleases(files []string) ([]string, error) {
	var result []string
	var uniqueTargets = map[string]string{}

	labelSet := Set{Files: files}
	chunks := labelSet.Chunks()

	for _, chunk := range chunks {
		rdeps := Rdeps{
			Universe: ALL,
			Scope:    chunk.String(),
		}
		query := ConstructReleaseQuery(rdeps.String())

		logrus.Info("querying release targets...")
		logrus.Debugf("bazel query: [ %q ]", query)
		targets, err := a.Runner.RunQuery(query)
		if err != nil {
			return nil, err
		}

		for _, target := range targets{
			uniqueTargets[target] = ""
		}
	}

	for label := range uniqueTargets{
		result = append(result, label)
	}

	return result, nil
}

func ConstructReleaseQuery(scope string) string {
	releaseQuery := Kind{
		Pattern: "artifact_ci_release",
		Scope: scope,
	}

	releases := Let{
		Name:  "releases",
		Value: releaseQuery.String(),
	}

	query := releases.Var()
	noCITags := Attr{Name: "tags", Input: "no-ci", Scope: releases.Var()}
	query = appendExceptions(query, []Attr{noCITags})
	query = prependLet(query, releases)
	return query
}
