package bazel_test

import (
	"io/ioutil"
	"os"
	"path/filepath"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"
	"pinterest.com/bazel-rules/build-collector/cmd/bazel"
)

var _ = Describe("Query Helpers", func() {
	var (
		dir string
		err error
	)

	BeforeEach(func() {
		dir, err = ioutil.TempDir("", "find-test")
		Expect(err).NotTo(HaveOccurred())
	})

	AfterEach(func() { os.RemoveAll(dir) })

	Context("AllInBUILDFiles", func() {
		It("replaces :BUILD labels with ':all' in order to collect all target defined within the package", func() {
			files := bazel.AllInBUILDFiles([]string{"//:BUILD", "//another:BUILD", "//some/other:BUILD.bazel"})
			Expect(files).To(Equal([]string{"//:all", "//another:all", "//some/other:all"}))
		})
	})

	Context("LocateBUILDFile", func() {
		It("checks if a BUILD file exists under the directory", func() {
			found, foundPath := bazel.LocateBUILDFile(dir)
			Expect(found).To(BeFalse())
			Expect(foundPath).To(BeEmpty())

			buildFilePath := filepath.Join(dir, "BUILD")
			err := ioutil.WriteFile(buildFilePath, []byte(`contents`), 0644)
			Expect(err).NotTo(HaveOccurred())

			found, foundPath = bazel.LocateBUILDFile(dir)
			Expect(found).To(BeTrue())
			Expect(foundPath).To(Equal(buildFilePath))
		})
	})
})
