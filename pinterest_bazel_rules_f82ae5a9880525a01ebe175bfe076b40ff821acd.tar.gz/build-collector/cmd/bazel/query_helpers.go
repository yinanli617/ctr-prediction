package bazel

import (
	"fmt"
	"os"
	"path/filepath"
	"strings"
)

func (a Analyzer) AnalyzeBUILDFiles(files []string) ([]string, error) {
	setQuery := Set{Files: files}
	labels, err := a.Runner.RunQuery(setQuery.String())
	if err != nil {
		return nil, fmt.Errorf("failed getting BUILD labels: %s", err)
	}

	return AllInBUILDFiles(labels), nil
}

func (a Analyzer) AnalyzeExtensionFiles(files []string) ([]string, error) {
	rbuildFilesQuery := RbuildFiles{Scope: strings.Join(files, ",")}
	labels, err := a.Runner.RunSkyQuery(rbuildFilesQuery.String())

	if err != nil {
		return nil, fmt.Errorf("failed getting BUILD labels: %s", err)
	}

	return AllInBUILDFiles(labels), nil
}

func (a Analyzer) AnalyzeDeletedFiles(files []string) ([]string, error) {
	buildFiles := []string{}

	for _, file := range files {
		parentDir := filepath.Dir(file)
		directory := ""

		for parentDir != directory {
			directory = parentDir
			found, foundPath := LocateBUILDFile(directory)

			if found {
				buildFiles = append(buildFiles, foundPath)
			}
			parentDir = filepath.Dir(directory)
		}
	}

	return a.AnalyzeBUILDFiles(buildFiles)
}

func LocateBUILDFile(dir string) (bool, string) {
	paths := []string{
		filepath.Join(dir, "BUILD"),
		filepath.Join(dir, "BUILD.bazel"),
	}

	for _, path := range paths {
		if _, err := os.Stat(path); !os.IsNotExist(err) {
			return true, path
		}
	}

	return false, ""
}

func AllInBUILDFiles(files []string) []string {
	for i, file := range files {
		files[i] = strings.SplitN(file, ":", 2)[0] + ":all"
	}

	return files
}
