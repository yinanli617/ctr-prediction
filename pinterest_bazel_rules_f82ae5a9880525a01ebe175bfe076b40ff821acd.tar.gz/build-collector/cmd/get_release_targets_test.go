package cmd_test

import (
	"errors"
	"io/ioutil"
	"os"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	"github.com/golang/mock/gomock"
	"pinterest.com/bazel-rules/build-collector/cmd"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
	"pinterest.com/bazel-rules/build-collector/cmd/mocks"
)

var _ = Describe("get-release-targets", func() {
	var (
		mockCtrl      *gomock.Controller
		mockAnalyzer  *mocks.MockAnalyzer
		mockCollector *mocks.MockCollector
		grtCmd        cmd.GetReleaseTargetsCmd
		outputFile    *os.File
		tempDir       string
		err           error
	)

	BeforeEach(func() {
		mockCtrl = gomock.NewController(GinkgoT())
		mockAnalyzer = mocks.NewMockAnalyzer(mockCtrl)
		mockCollector = mocks.NewMockCollector(mockCtrl)
		grtCmd = cmd.NewGetReleaseTargetsCmd(mockAnalyzer, mockCollector)

		tempDir, err = ioutil.TempDir("", "get-release-targets")
		Expect(err).NotTo(HaveOccurred())

		outputFile, err = ioutil.TempFile(tempDir, "output-file")
		Expect(err).NotTo(HaveOccurred())

		grtCmd.Dir = tempDir
		grtCmd.OutputFile = outputFile.Name()
	})

	AfterEach(func() {
		mockCtrl.Finish()
		os.RemoveAll(tempDir)
	})

	It("writes the affected test targets to a JSON file ", func() {
		fileCollection := collect.FileCollection{
			SourceFiles: []string{"some-file.sh"},
			BUILDFiles:  []string{"some-dir/BUILD"},
		}

		mockCollector.EXPECT().Files(tempDir).Return(fileCollection, nil)
		mockAnalyzer.EXPECT().FindReleases(
			tempDir,
			fileCollection,
		).Return([]string{":release_target", "//dir:release_target"}, nil)

		err := grtCmd.Run()
		Expect(err).NotTo(HaveOccurred())

		result := parseResultFile(grtCmd.OutputFile)
		Expect(result.NumberOfTargets).To(Equal(2))
		Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some-file.sh"))
		Expect(result.ChangedFiles.BUILDFiles).To(ContainElement("some-dir/BUILD"))
		Expect(result.Targets).To(Equal([]cmd.Target{
			cmd.Target{
				Label:   "//dir:release_target",
			},
			cmd.Target{
				Label:   ":release_target",
			},
		}))
	})

	Context("Error Cases", func() {
		Context("When the directory does not exist", func() {
			It("returns an error", func() {
				grtCmd.Dir = "bad directory"

				err := grtCmd.Run()
				Expect(err).To(MatchError("Failed to find directory \"bad directory\": stat bad directory: no such file or directory"))
			})
		})

		Context("When collecting files fails", func() {
			It("returns an error", func() {
				mockCollector.EXPECT().Files(tempDir).Return(collect.FileCollection{}, errors.New("oh no"))

				err := grtCmd.Run()
				Expect(err).To(MatchError("Failed to collect files: oh no"))
			})
		})

		Context("When finding releases fails", func() {
			It("returns an error", func() {
				mockCollector.EXPECT().Files(tempDir).Return(collect.FileCollection{}, nil)
				mockAnalyzer.EXPECT().FindReleases(tempDir, gomock.Any()).Return(nil, errors.New("bad news")).Times(1)

				err := grtCmd.Run()
				Expect(err).To(MatchError("Failed to find releases: bad news"))
			})
		})

		Context("When writing the JSON file fails", func() {
			BeforeEach(func() {
				mockCollector.EXPECT().Files(tempDir).Return(collect.FileCollection{}, nil)
				mockAnalyzer.EXPECT().FindReleases(
					tempDir,
					collect.FileCollection{},
				).Return(nil, nil)
			})

			It("returns an error", func() {
				grtCmd.OutputFile = "dir-doesnt-exist/blah.json"

				err = grtCmd.Run()
				Expect(err).To(MatchError("Failed to write JSON file with release target information to \"dir-doesnt-exist/blah.json\": open dir-doesnt-exist/blah.json: no such file or directory"))
			})
		})

	})
})
