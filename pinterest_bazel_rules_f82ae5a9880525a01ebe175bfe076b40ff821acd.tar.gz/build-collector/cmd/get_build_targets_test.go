package cmd_test

import (
	"errors"
	"io/ioutil"
	"os"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	"github.com/golang/mock/gomock"
	"pinterest.com/bazel-rules/build-collector/cmd"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
	"pinterest.com/bazel-rules/build-collector/cmd/mocks"
)

var _ = Describe("get-build-targets", func() {
	var (
		mockCtrl      *gomock.Controller
		mockAnalyzer  *mocks.MockAnalyzer
		mockCollector *mocks.MockCollector
		gbtCmd        cmd.GetBuildTargetsCmd
		outputFile    *os.File
		tempDir       string
		err           error
	)

	BeforeEach(func() {
		mockCtrl = gomock.NewController(GinkgoT())
		mockAnalyzer = mocks.NewMockAnalyzer(mockCtrl)
		mockCollector = mocks.NewMockCollector(mockCtrl)
		gbtCmd = cmd.NewGetBuildTargetsCmd(mockAnalyzer, mockCollector)

		tempDir, err = ioutil.TempDir("", "get-test-targets")
		Expect(err).NotTo(HaveOccurred())

		outputFile, err = ioutil.TempFile(tempDir, "output-file")
		Expect(err).NotTo(HaveOccurred())

		gbtCmd.Dir = tempDir
		gbtCmd.OutputFile = outputFile.Name()
	})

	AfterEach(func() {
		mockCtrl.Finish()
		os.RemoveAll(tempDir)
	})

	It("writes the affected build targets to a JSON file", func() {
		fileCollection := collect.FileCollection{
			SourceFiles: []string{"some-file.sh"},
			BUILDFiles:  []string{"some-dir/BUILD"},
		}
		targetCollection := []string{"//:some-build-target", "//:another-build-target"}

		mockCollector.EXPECT().Files(tempDir).Return(fileCollection, nil)
		mockAnalyzer.EXPECT().FindBinaries(
			tempDir,
			fileCollection,
		).Return(targetCollection, nil)

		err := gbtCmd.Run()
		Expect(err).NotTo(HaveOccurred())

		result := parseResultFile(gbtCmd.OutputFile)
		Expect(result.NumberOfTargets).To(Equal(2))
		Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some-file.sh"))
		Expect(result.ChangedFiles.BUILDFiles).To(ContainElement("some-dir/BUILD"))
		Expect(result.Targets).To(Equal([]cmd.Target{
			cmd.Target{
				Label: "//:another-build-target",
			},
			cmd.Target{
				Label: "//:some-build-target",
			},
		}))
	})

	Context("Error Cases", func() {
		Context("When collecting files fails", func() {
			It("returns an error", func() {
				mockCollector.EXPECT().Files(tempDir).Return(collect.FileCollection{}, errors.New("oh no"))

				err := gbtCmd.Run()
				Expect(err).To(MatchError("failed to collect files: oh no"))
			})
		})

		Context("When finding binaries fails", func() {
			It("returns an error", func() {
				mockCollector.EXPECT().Files(tempDir).Return(collect.FileCollection{}, nil)
				mockAnalyzer.EXPECT().FindBinaries(tempDir, gomock.Any()).Return(nil, errors.New("bad news")).Times(1)

				err := gbtCmd.Run()
				Expect(err).To(MatchError("failed to find binaries: bad news"))
			})
		})

		Context("When writing the JSON file fails", func() {
			BeforeEach(func() {
				mockCollector.EXPECT().Files(tempDir).Return(collect.FileCollection{}, nil)
				mockAnalyzer.EXPECT().FindBinaries(
					tempDir,
					collect.FileCollection{},
				).Return(nil, nil)
			})

			It("returns an error", func() {
				gbtCmd.OutputFile = "dir-doesnt-exist/blah.json"

				err = gbtCmd.Run()
				Expect(err).To(MatchError("failed to write JSON file with build target information to \"dir-doesnt-exist/blah.json\": open dir-doesnt-exist/blah.json: no such file or directory"))
			})
		})

		Context("When the directory does not exist", func() {
			It("returns an error", func() {
				gbtCmd.Dir = "bad directory"

				err := gbtCmd.Run()
				Expect(err).To(MatchError("failed to find directory \"bad directory\": stat bad directory: no such file or directory"))
			})
		})
	})
})
