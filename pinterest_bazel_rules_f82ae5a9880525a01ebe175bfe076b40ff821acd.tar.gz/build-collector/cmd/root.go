package cmd

import (
	"fmt"
	"os"

	"github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
)


var LogLevel string
var rootCmd = &cobra.Command{
	Use:   "build-collector",
	Version:   "0.1.1",
	Short: "build-collector is used to collect and dispatch bazel targets.",
	Long:  "A CLI that utilizes bazel for for querying and dispatching targets.",
	PersistentPreRunE: func(cmd *cobra.Command, args []string) error {
		logrus.SetOutput(os.Stdout)
		logrus.SetFormatter(&logrus.TextFormatter{
			DisableTimestamp: true,
		})
		return nil
	},
}

func Execute() {
	if err := rootCmd.Execute(); err != nil {
		_ = fmt.Errorf("failed to run build-collector: %s", err)
		os.Exit(1)
	}
}

func init() {
	cobra.OnInitialize(initConfig)
	rootCmd.PersistentFlags().StringVarP(&LogLevel, "log-level", "v", "info", "log level options: [debug, info]")
	rootCmd.AddCommand(NewGTTCmd())
	rootCmd.AddCommand(NewGTWCmd())
	rootCmd.AddCommand(NewGBTCmd())
	rootCmd.AddCommand(NewGRTCmd())
}

func initConfig() {
	logLevel, _ := rootCmd.Flags().GetString("log-level")
	switch logLevel {
	case "debug":
		logrus.SetLevel(logrus.DebugLevel)
	default:
		logrus.SetLevel(logrus.InfoLevel)
	}
}
