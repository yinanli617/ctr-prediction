package cmd

import (
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
)

//go:generate mockgen -destination=mocks/query.go -package=mocks pinterest.com/bazel-rules/build-collector/cmd Analyzer
type Analyzer interface {
	FindTests(string, collect.FileCollection) (map[string]int, error)
	FindBinaries(string, collect.FileCollection) ([]string, error)
	FindReleases(string, collect.FileCollection) ([]string, error)
}

//go:generate mockgen -destination=mocks/collect.go -package=mocks pinterest.com/bazel-rules/build-collector/cmd Collector
type Collector interface {
	Files(dir string) (collect.FileCollection, error)
}

// TargetResults are used to format all the collected
// targets in a results file
type TargetResults struct {
	NumberOfTargets int                    `json:"numberOfTargets"`
	ChangedFiles    collect.FileCollection `json:"changedFiles"`
	Targets         []Target               `json:"targets"`
}

// Target is used to format a target instance
// in a results file
type Target struct {
	Label   string `json:"label"`
	Timeout int    `json:"timeout,omitempty"`
}
