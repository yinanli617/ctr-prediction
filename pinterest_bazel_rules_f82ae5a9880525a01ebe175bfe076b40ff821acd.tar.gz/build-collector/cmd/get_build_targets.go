package cmd

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"

	"github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"pinterest.com/bazel-rules/build-collector/cmd/bazel"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
)

type GetBuildTargetsCmd struct {
	Analyzer   Analyzer
	Collector  Collector
	Dir        string
	OutputFile string
}

func NewGetBuildTargetsCmd(analyzer Analyzer, collector Collector) GetBuildTargetsCmd {
	return GetBuildTargetsCmd{
		Analyzer:  analyzer,
		Collector: collector,
	}
}

func NewGBTCmd() *cobra.Command {
	collector := collect.NewCollector()
	analyzer := bazel.NewAnalyzer()
	gbt := NewGetBuildTargetsCmd(analyzer, collector)

	cmd := &cobra.Command{
		Use:   "get-build-targets",
		Short: "Returns bazel build targets",
		Long:  `Finds the affected bazel build targets based on two git commits and writes them to a JSON file`,
		RunE: func(cmd *cobra.Command, args []string) error {
			return gbt.Run()
		},
	}

	flags := cmd.Flags()
	flags.StringVarP(&gbt.Dir, "directory", "d", "", "directory to read from (required)")
	flags.StringVarP(&collector.PreviousCommit, "previous-commit", "p", "", "previous commit to compare from (required)")
	flags.StringVarP(&collector.LatestCommit, "latest-commit", "l", "", "latest commit to compare to (required)")
	flags.StringVarP(&gbt.OutputFile, "output-file", "o", "build-targets.json", "path to result file of build targets")

	cmd.MarkFlagRequired("directory")
	cmd.MarkFlagRequired("previous-commit")
	cmd.MarkFlagRequired("latest-commit")

	return cmd
}

func (gbt *GetBuildTargetsCmd) Run() error {
	logrus.Infof("verifying directory %q exists...", gbt.Dir)
	if _, err := os.Stat(gbt.Dir); os.IsNotExist(err) {
		return fmt.Errorf("failed to find directory %q: %s", gbt.Dir, err)
	}

	logrus.Info("collecting modified files...")
	fileCollection, err := gbt.Collector.Files(gbt.Dir)
	if err != nil {
		return fmt.Errorf("failed to collect files: %s", err)
	}

	logrus.Info("collecting affected bazel build targets...")
	targets, err := gbt.Analyzer.FindBinaries(gbt.Dir, fileCollection)
	if err != nil {
		return fmt.Errorf("failed to find binaries: %s", err)
	}

	logrus.Info("formatting results to JSON...")
	results := FormatResults(formatBuild(targets), fileCollection)
	file, err := json.MarshalIndent(results, "", " ")
	if err != nil {
		return fmt.Errorf("failed to marshall JSON: %s", err)
	}

	logrus.Infof("writing results to %q...", gbt.OutputFile)
	if err := ioutil.WriteFile(gbt.OutputFile, file, 0644); err != nil {
		return fmt.Errorf("failed to write JSON file with build target information to %q: %s", gbt.OutputFile, err)
	}

	return nil
}

func formatBuild(targets []string) []Target {
	result := []Target{}
	for _, label := range targets {
		target := Target{
			Label: label,
		}
		result = append(result, target)
	}

	return result
}
