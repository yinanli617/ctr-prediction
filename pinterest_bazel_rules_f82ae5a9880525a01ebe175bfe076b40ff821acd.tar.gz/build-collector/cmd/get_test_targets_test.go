package cmd_test

import (
	"encoding/json"
	"errors"
	"io/ioutil"
	"os"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	"github.com/golang/mock/gomock"
	"pinterest.com/bazel-rules/build-collector/cmd"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
	"pinterest.com/bazel-rules/build-collector/cmd/mocks"
)

var _ = Describe("get-test-targets", func() {
	var (
		mockCtrl      *gomock.Controller
		mockAnalyzer  *mocks.MockAnalyzer
		mockCollector *mocks.MockCollector
		gttCmd        cmd.GetTestTargetsCmd
		outputFile    *os.File
		tempDir       string
		err           error
	)

	BeforeEach(func() {
		mockCtrl = gomock.NewController(GinkgoT())
		mockAnalyzer = mocks.NewMockAnalyzer(mockCtrl)
		mockCollector = mocks.NewMockCollector(mockCtrl)
		gttCmd = cmd.NewGetTestTargetsCmd(mockAnalyzer, mockCollector)

		tempDir, err = ioutil.TempDir("", "get-test-targets")
		Expect(err).NotTo(HaveOccurred())

		outputFile, err = ioutil.TempFile(tempDir, "output-file")
		Expect(err).NotTo(HaveOccurred())

		gttCmd.Dir = tempDir
		gttCmd.OutputFile = outputFile.Name()
	})

	AfterEach(func() {
		mockCtrl.Finish()
		os.RemoveAll(tempDir)
	})

	It("writes the affected test targets to a JSON file ", func() {
		fileCollection := collect.FileCollection{
			SourceFiles: []string{"some-file.sh"},
			BUILDFiles:  []string{"some-dir/BUILD"},
		}
		targetCollection := map[string]int{
			":short-target":    1,
			":moderate-target": 5,
			":long-target":     15,
			":eternal-target":  60,
		}

		mockCollector.EXPECT().Files(tempDir).Return(fileCollection, nil)
		mockAnalyzer.EXPECT().FindTests(
			tempDir,
			fileCollection,
		).Return(targetCollection, nil)

		err := gttCmd.Run()
		Expect(err).NotTo(HaveOccurred())

		result := parseResultFile(gttCmd.OutputFile)
		Expect(result.NumberOfTargets).To(Equal(4))
		Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some-file.sh"))
		Expect(result.ChangedFiles.BUILDFiles).To(ContainElement("some-dir/BUILD"))
		Expect(result.Targets).To(Equal([]cmd.Target{
			cmd.Target{
				Label:   ":eternal-target",
				Timeout: 60,
			},
			cmd.Target{
				Label:   ":long-target",
				Timeout: 15,
			},
			cmd.Target{
				Label:   ":moderate-target",
				Timeout: 5,
			},
			cmd.Target{
				Label:   ":short-target",
				Timeout: 1,
			},
		}))
	})

	Context("FormatResults", func() {
		It("returns a sorted list of test targets and the changed files", func() {
			targets := []cmd.Target{
				cmd.Target{
					Label:   ":c-target",
					Timeout: 5,
				},
				cmd.Target{
					Label:   ":b-target",
					Timeout: 60,
				},
				cmd.Target{
					Label:   ":a-target",
					Timeout: 15,
				},
				cmd.Target{
					Label:   "//a-dir:b-target",
					Timeout: 5,
				},
				cmd.Target{
					Label:   "//a-dir:a-target",
					Timeout: 5,
				},
				cmd.Target{
					Label:   "//a-dir/b-dir:c-target",
					Timeout: 10,
				},
				cmd.Target{
					Label:   "//b-dir:d-target",
					Timeout: 5,
				},
				cmd.Target{
					Label:   "//b-dir:c-target",
					Timeout: 5,
				},
			}

			collection := collect.FileCollection{
				SourceFiles: []string{"some-file.sh"},
			}

			result := cmd.FormatResults(targets, collection)
			Expect(result).To(Equal(cmd.TargetResults{
				NumberOfTargets: 8,
				ChangedFiles:    collection,
				Targets: []cmd.Target{
					cmd.Target{
						Label:   "//a-dir/b-dir:c-target",
						Timeout: 10,
					},
					cmd.Target{
						Label:   "//a-dir:a-target",
						Timeout: 5,
					},
					cmd.Target{
						Label:   "//a-dir:b-target",
						Timeout: 5,
					},
					cmd.Target{
						Label:   "//b-dir:c-target",
						Timeout: 5,
					},
					cmd.Target{
						Label:   "//b-dir:d-target",
						Timeout: 5,
					},
					cmd.Target{
						Label:   ":a-target",
						Timeout: 15,
					},
					cmd.Target{
						Label:   ":b-target",
						Timeout: 60,
					},
					cmd.Target{
						Label:   ":c-target",
						Timeout: 5,
					},
				},
			}))
		})
	})

	Context("Error Cases", func() {
		Context("When collecting files fails", func() {
			It("returns an error", func() {
				mockCollector.EXPECT().Files(tempDir).Return(collect.FileCollection{}, errors.New("oh no"))

				err := gttCmd.Run()
				Expect(err).To(MatchError("Failed to collect files: oh no"))
			})
		})

		Context("When finding tests fails", func() {
			It("returns an error", func() {
				mockCollector.EXPECT().Files(tempDir).Return(collect.FileCollection{}, nil)
				mockAnalyzer.EXPECT().FindTests(tempDir, gomock.Any()).Return(nil, errors.New("bad news")).Times(1)

				err := gttCmd.Run()
				Expect(err).To(MatchError("Failed to find tests: bad news"))
			})
		})

		Context("When writing the JSON file fails", func() {
			BeforeEach(func() {
				mockCollector.EXPECT().Files(tempDir).Return(collect.FileCollection{}, nil)
				mockAnalyzer.EXPECT().FindTests(
					tempDir,
					collect.FileCollection{},
				).Return(map[string]int{}, nil)
			})

			It("returns an error", func() {
				gttCmd.OutputFile = "dir-doesnt-exist/blah.json"

				err = gttCmd.Run()
				Expect(err).To(MatchError("Failed to write JSON file with test target information to \"dir-doesnt-exist/blah.json\": open dir-doesnt-exist/blah.json: no such file or directory"))
			})
		})

		Context("When the directory does not exist", func() {
			It("returns an error", func() {
				gttCmd.Dir = "bad directory"

				err := gttCmd.Run()
				Expect(err).To(MatchError("Failed to find directory \"bad directory\": stat bad directory: no such file or directory"))
			})
		})
	})
})

func parseResultFile(file string) cmd.TargetResults {
	fileContents, err := ioutil.ReadFile(file)
	Expect(err).NotTo(HaveOccurred())

	result := cmd.TargetResults{}
	err = json.Unmarshal(fileContents, &result)
	Expect(err).NotTo(HaveOccurred())
	return result
}
