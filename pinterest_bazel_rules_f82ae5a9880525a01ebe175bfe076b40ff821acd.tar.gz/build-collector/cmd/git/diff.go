package git

import (
	"fmt"

	"github.com/sirupsen/logrus"
	"pinterest.com/bazel-rules/build-collector/cmd/run"
)

type Runner interface {
	Run(string, ...string) ([]string, error)
	SetDir(string)
}

type Differ struct {
	Runner Runner
}

func NewDiffer() *Differ {
	return &Differ{
		Runner: run.NewCmdRunner(),
	}
}

func (d Differ) Diff(dir, previousCommit, latestCommit string) ([]string, []string, error) {
	d.Runner.SetDir(dir)

	logrus.Infof("verifying [%q %q] are valid git commits...", previousCommit, latestCommit)
	err := d.VerifyCommits(previousCommit, latestCommit)
	if err != nil {
		return nil, nil, fmt.Errorf("Failed to verify commits: %s", err)
	}

	logrus.Info("looking for deleted files...")
	// --diff-filter=D will only show deleted files
	args := []string{"diff", "--name-only", "--diff-filter=D", previousCommit, latestCommit}
	deletedFiles, err := d.Runner.Run("git", args...)
	if err != nil {
		return nil, nil, fmt.Errorf("Failed to get deleted files: %s", err)
	}

	logrus.Info("looking for all other modified files...")
	// --diff-filter=d will exclude deleted files
	args = []string{"diff", "--name-only", "--diff-filter=d", previousCommit, latestCommit}
	files, err := d.Runner.Run("git", args...)
	if err != nil {
		return nil, nil, fmt.Errorf("Failed to get modified files: %s", err)

	}

	return files, deletedFiles, err
}

func (d Differ) VerifyCommits(commits ...string) error {
	for _, commit := range commits {
		args := []string{"rev-parse", "--verify", commit}
		_, err := d.Runner.Run("git", args...)
		if err != nil {
			return err
		}
	}

	return nil
}
