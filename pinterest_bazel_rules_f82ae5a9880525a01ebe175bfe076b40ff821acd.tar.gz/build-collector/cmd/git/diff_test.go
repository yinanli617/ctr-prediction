package git_test

import (
	"errors"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	"github.com/golang/mock/gomock"
	"pinterest.com/bazel-rules/build-collector/cmd/git"
	"pinterest.com/bazel-rules/build-collector/cmd/mocks"
)

var _ = Describe("Diff", func() {
	var (
		differ     *git.Differ
		mockCtrl   *gomock.Controller
		mockRunner *mocks.MockRunner
		dir        string
	)

	BeforeEach(func() {
		mockCtrl = gomock.NewController(GinkgoT())
		mockRunner = mocks.NewMockRunner(mockCtrl)

		differ = git.NewDiffer()
		differ.Runner = mockRunner
		dir = "som-dir"
	})

	It("returns a list of modified and deleted files", func() {
		mockRunner.EXPECT().SetDir(dir).Times(1)

		mockRunner.EXPECT().Run("git", "rev-parse", "--verify", "some-commit")
		mockRunner.EXPECT().Run("git", "rev-parse", "--verify", "another-commit")

		mockRunner.EXPECT().Run("git", "diff",
			"--name-only", "--diff-filter=D", "some-commit", "another-commit",
		).Return([]string{"some-deleted-file"}, nil).Times(1)
		mockRunner.EXPECT().Run("git", "diff",
			"--name-only", "--diff-filter=d", "some-commit", "another-commit",
		).Return([]string{"some-file"}, nil).Times(1)

		files, deletedFiles, err := differ.Diff(dir, "some-commit", "another-commit")
		Expect(err).NotTo(HaveOccurred())
		Expect(files).To(ContainElement("some-file"))
		Expect(deletedFiles).To(ContainElement("some-deleted-file"))
	})

	Context("Error Cases", func() {
		Context("When the command runner fails to get deleted files", func() {
			It("returns an error", func() {
				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().Run("git", "rev-parse", "--verify", "some-commit")
				mockRunner.EXPECT().Run("git", "rev-parse", "--verify", "another-commit")
				mockRunner.EXPECT().Run(gomock.Any(), gomock.Any()).Return(nil, errors.New("bad run")).Times(1)

				_, _, err := differ.Diff(dir, "some-commit", "another-commit")
				Expect(err).To(MatchError("Failed to get deleted files: bad run"))
			})
		})
		Context("When the command runner fails to get modified files", func() {
			It("returns an error", func() {
				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().Run("git", "rev-parse", "--verify", "some-commit")
				mockRunner.EXPECT().Run("git", "rev-parse", "--verify", "another-commit")

				mockRunner.EXPECT().Run(gomock.Any(), gomock.Any())
				mockRunner.EXPECT().Run(gomock.Any(), gomock.Any()).Return(nil, errors.New("bad run")).Times(1)

				_, _, err := differ.Diff(dir, "some-commit", "another-commit")
				Expect(err).To(MatchError("Failed to get modified files: bad run"))
			})
		})

		Context("When the verifying a commit fails", func() {
			It("returns an error", func() {
				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().Run("git", "rev-parse", "--verify", "some-commit").Return(nil, errors.New("uh oh")).Times(1)

				_, _, err := differ.Diff(dir, "some-commit", "another-commit")
				Expect(err).To(MatchError("Failed to verify commits: uh oh"))
			})
		})
	})
})
