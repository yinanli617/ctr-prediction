package cmd

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"

	"github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
)

type GetTestWorkloadsCmd struct {
	TargetsPath string
	OutputFile  string
	CPU         int
}

type TestTarget struct {
	Label   string `json:"label"`
	Timeout int    `json:"timeout"`
}

type Workload struct {
	Targets []TestTarget `json:"targets"`
}

type Batch struct {
	CPUTime           int        `json:"CPUTime"` //The product of CPU and longest test Timeout
	NumberOfWorkloads int        `json:"numberOfWorkloads"`
	Workloads         [][]string `json:"workloads"`
}

func NewGetTestWorkloadsCmd() GetTestWorkloadsCmd {
	return GetTestWorkloadsCmd{}
}

func NewGTWCmd() *cobra.Command {
	gtw := NewGetTestWorkloadsCmd()
	cmd := &cobra.Command{
		Use:   "get-test-workloads",
		Short: "Returns test workloads",
		Long:  `Returns a json file containing the batch of workloads given a json file of test targets.`,
		RunE: func(cmd *cobra.Command, args []string) error {
			return gtw.Run()
		},
	}

	flags := cmd.Flags()
	flags.StringVarP(&gtw.TargetsPath, "test-targets", "t", "", "file for command to read list of test targets from")
	flags.IntVarP(&gtw.CPU, "cpu", "c", 0, "CPU available on the worker. Used to calculate the amount of tests assigned to each worker")
	flags.StringVarP(&gtw.OutputFile, "output-file", "o", "workloads.json", "path to resulting workload file")

	cmd.MarkFlagRequired("test-targets")
	cmd.MarkFlagRequired("cpu")

	return cmd
}

func (gtw GetTestWorkloadsCmd) Run() error {
	logrus.Infof("verifying %q exists...", gtw.TargetsPath)
	if _, err := os.Stat(gtw.TargetsPath); os.IsNotExist(err) {
		return fmt.Errorf("Failed to find test target file %q: %s", gtw.TargetsPath, err)
	}

	logrus.Info("parsing JSON in test target file...")
	targetFile, err := ioutil.ReadFile(gtw.TargetsPath)
	if err != nil {
		return fmt.Errorf("Failed to read file %q: %s", gtw.TargetsPath, err)
	}

	data := Workload{}
	if err := json.Unmarshal(targetFile, &data); err != nil {
		return fmt.Errorf("Failed to parse JSON in %q: %s", gtw.TargetsPath, err)
	}

	testTargets := data.Targets
	if len(testTargets) == 0 {
		return fmt.Errorf("No test targets found in %q. Workload file not created.", gtw.TargetsPath)
	}

	logrus.Info("calculating batch of test workloads...")
	batch := gtw.CalculateBatch(testTargets)

	logrus.Info("formatting results to JSON...")
	file, err := json.MarshalIndent(batch, "", " ")
	if err != nil {
		return fmt.Errorf("Failed to marshall workload information to JSON: %s", err)
	}

	logrus.Infof("writing results to %q...", gtw.OutputFile)
	if err := ioutil.WriteFile(gtw.OutputFile, file, 0644); err != nil {
		return fmt.Errorf("Failed to write JSON file with workload information to %q: %s", gtw.OutputFile, err)
	}

	return nil
}

func (gtw *GetTestWorkloadsCmd) CalculateBatch(targets []TestTarget) Batch {
	batch := Batch{}

	cpuTime := findLongestTimeout(targets) * gtw.CPU
	batch.CPUTime = cpuTime

	workload := []string{}
	timeLeftOver := cpuTime
	for _, target := range targets {
		timeLeftOver = timeLeftOver - target.Timeout
		if timeLeftOver >= 0 {
			workload = append(workload, target.Label)
		} else {
			batch.Workloads = append(batch.Workloads, workload)
			workload = []string{target.Label}
			timeLeftOver = cpuTime - target.Timeout
		}
	}

	if len(workload) > 0 {
		batch.Workloads = append(batch.Workloads, workload)
	}
	batch.NumberOfWorkloads = len(batch.Workloads)

	return batch
}

func findLongestTimeout(targets []TestTarget) int {
	longestTimeout := 1
	for i := range targets {
		if longestTimeout < targets[i].Timeout {
			longestTimeout = targets[i].Timeout
		}
	}

	return longestTimeout
}
