package collect_test

import (
	"errors"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	"github.com/golang/mock/gomock"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
	"pinterest.com/bazel-rules/build-collector/cmd/mocks"
)

var _ = Describe("Collector", func() {
	var (
		c          *collect.Collector
		dir        string
		mockCtrl   *gomock.Controller
		mockDiffer *mocks.MockDiffer
		mockRunner *mocks.MockRunner
	)

	BeforeEach(func() {
		mockCtrl = gomock.NewController(GinkgoT())
		mockDiffer = mocks.NewMockDiffer(mockCtrl)
		mockRunner = mocks.NewMockRunner(mockCtrl)

		dir = "some-dir"
		c = collect.NewCollector()
		c.Differ = mockDiffer
		c.Runner = mockRunner
		c.PreviousCommit = "some-git-sha"
		c.LatestCommit = "some-git-sha"
	})

	Context("Files", func() {
		It("returns a file collection", func() {
			files := []string{
				"some-file.sh",
				"some-dir/BUILD",
				"some-dir/some-ext.bzl",
				"WORKSPACE",
			}
			deletedFiles := []string{"deleted.sh"}

			mockDiffer.EXPECT().Diff(dir, c.PreviousCommit, c.LatestCommit).Return(files, deletedFiles, nil).Times(1)
			mockRunner.EXPECT().SetDir(dir).Times(1)
			mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, nil).Times(1)

			fileCollection, err := c.Files(dir)
			Expect(err).NotTo(HaveOccurred())
			Expect(fileCollection).To(Equal(
				collect.FileCollection{
					WORKSPACE:      true,
					SourceFiles:    []string{"some-file.sh"},
					BUILDFiles:     []string{"some-dir/BUILD"},
					ExtensionFiles: []string{"some-dir/some-ext.bzl"},
					DeletedFiles:   []string{"deleted.sh"},
					IgnoredFiles:   []string{},
				},
			))
		})

		Context("Error Cases", func() {
			Context("When diffing for files fails ", func() {
				It("returns an error", func() {
					mockDiffer.EXPECT().Diff(
						dir,
						c.PreviousCommit,
						c.LatestCommit,
					).Return(nil, nil, errors.New("uh oh")).Times(1)
					mockRunner.EXPECT().SetDir(dir).Times(1)
					mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, nil).Times(1)

					_, err := c.Files(dir)
					Expect(err).To(MatchError("Failed to diff modified files: uh oh"))
				})
			})
		})
	})

	Context("ParseFiles", func() {
		Context("When a source file doesn't have a corresponding bazel label", func() {
			It("adds them to the list of ignored files", func() {
				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery("no-bazel-label.sh").Return(nil, errors.New("uh oh")).Times(1)

				collection := c.ParseFiles(dir, []string{"no-bazel-label.sh"})
				Expect(collection.IgnoredFiles).To(ContainElement("no-bazel-label.sh"))
			})
		})

		Context("When a source file has a corresponding bazel label", func() {
			It("adds them to the list of source files", func() {
				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery("some-file.sh").Return([]string{"some-file.sh"}, nil).Times(1)

				collection := c.ParseFiles(dir, []string{"some-file.sh"})
				Expect(collection.SourceFiles).To(ContainElement("some-file.sh"))
				Expect(collection.IgnoredFiles).ToNot(ContainElement("some-file.sh"))
			})
		})

		Context("WORKSPACE files", func() {
			It("only matches files named WORKSPACE or WORKSPACE.bazel", func() {
				collection := c.ParseFiles(dir, []string{"WORKSPACE.bazel"})
				Expect(collection.WORKSPACE).To(BeTrue())

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, nil).Times(1)

				collection = c.ParseFiles(dir, []string{"workspace"})
				Expect(collection.WORKSPACE).To(BeFalse())

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, nil).Times(1)

				collection = c.ParseFiles(dir, []string{"WORKSPACE.sh"})
				Expect(collection.WORKSPACE).To(BeFalse())

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, nil).Times(1)

				collection = c.ParseFiles(dir, []string{"myWORKSPACE"})
				Expect(collection.WORKSPACE).To(BeFalse())
			})
		})

		Context("BUILD files", func() {
			It("only matches files named BUILD or BUILD.bazel", func() {
				collection := c.ParseFiles(dir, []string{"BUILD.bazel"})
				Expect(collection.BUILDFiles).ToNot(BeEmpty())

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, nil).Times(1)

				collection = c.ParseFiles(dir, []string{"build"})
				Expect(collection.BUILDFiles).To(BeEmpty())

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, nil).Times(1)

				collection = c.ParseFiles(dir, []string{"BUILD.sh"})
				Expect(collection.BUILDFiles).To(BeEmpty())

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, nil).Times(1)

				collection = c.ParseFiles(dir, []string{"my-BUILD"})
				Expect(collection.BUILDFiles).To(BeEmpty())
			})
		})

		Context("Extension Files", func() {
			It("only matches files with the .bzl extension", func() {
				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, nil).Times(1)

				collection := c.ParseFiles(dir, []string{"bzl"})
				Expect(collection.ExtensionFiles).To(BeEmpty())

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, nil).Times(1)

				collection = c.ParseFiles(dir, []string{"bzl.file"})
				Expect(collection.ExtensionFiles).To(BeEmpty())

				mockRunner.EXPECT().SetDir(dir).Times(1)
				mockRunner.EXPECT().RunQuery(gomock.Any()).Return(nil, nil).Times(1)

				collection = c.ParseFiles(dir, []string{".bzlfile"})
				Expect(collection.ExtensionFiles).To(BeEmpty())
			})
		})
	})
})
