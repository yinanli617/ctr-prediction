package collect

import (
	"fmt"
	"path/filepath"
	"regexp"

	"github.com/sirupsen/logrus"
	"pinterest.com/bazel-rules/build-collector/cmd/git"
	"pinterest.com/bazel-rules/build-collector/cmd/run"
)

//go:generate mockgen -destination=../mocks/diff.go -package=mocks pinterest.com/bazel-rules/build-collector/cmd/collect Differ
type Differ interface {
	Diff(string, string, string) ([]string, []string, error)
	VerifyCommits(...string) error
}

type Runner interface {
	RunQuery(string) ([]string, error)
	SetDir(string)
}

type Collector struct {
	Differ         Differ
	Runner         Runner
	PreviousCommit string
	LatestCommit   string
}

type FileCollection struct {
	WORKSPACE      bool     `json:"WORKSPACE"`
	SourceFiles    []string `json:"sourceFiles"`
	BUILDFiles     []string `json:"BUILDFiles"`
	ExtensionFiles []string `json:"extensionFiles"`
	DeletedFiles   []string `json:"deletedFiles"`
	IgnoredFiles   []string `json:"ignoredFiles"`
}

func NewCollector() *Collector {
	return &Collector{
		Differ: git.NewDiffer(),
		Runner: run.NewCmdRunner(),
	}
}

func (c *Collector) Files(dir string) (FileCollection, error) {
	files, deletedFiles, err := c.Differ.Diff(dir, c.PreviousCommit, c.LatestCommit)
	if err != nil {
		return FileCollection{}, fmt.Errorf("Failed to diff modified files: %s", err)
	}

	fileCollection := c.ParseFiles(dir, files)
	fileCollection.DeletedFiles = deletedFiles

	return fileCollection, nil
}

func (c *Collector) ParseFiles(dir string, files []string) FileCollection {
	workspaceFile := false
	BUILDFiles := []string{}
	extensionFiles := []string{}
	sourceFiles := []string{}
	ignoredFiles := []string{}

	workspace, build, bzl := createRegexPatterns()

	logrus.Info("grouping modified files by type...")
	for _, file := range files {
		basename := filepath.Base(file)

		if workspace.MatchString(file) {
			workspaceFile = true
		} else if build.MatchString(basename) {
			BUILDFiles = append(BUILDFiles, file)
		} else if bzl.MatchString(file) {
			extensionFiles = append(extensionFiles, file)
		} else {
			c.Runner.SetDir(dir)

			_, err := c.Runner.RunQuery(file)
			if err != nil {
				logrus.Warningf("an error occurred while running query to find bazel label for file: %q. Assuming file is unknown to bazel and ignoring.", file)
				ignoredFiles = append(ignoredFiles, file)
			} else {
				sourceFiles = append(sourceFiles, file)
			}
		}
	}

	return FileCollection{
		WORKSPACE:      workspaceFile,
		BUILDFiles:     BUILDFiles,
		ExtensionFiles: extensionFiles,
		SourceFiles:    sourceFiles,
		IgnoredFiles:   ignoredFiles,
	}
}

func createRegexPatterns() (*regexp.Regexp, *regexp.Regexp, *regexp.Regexp) {
	return regexp.MustCompile(`^WORKSPACE(\.bazel)?$`), regexp.MustCompile(`^BUILD(\.bazel)?$`), regexp.MustCompile(`^.*\.bzl$`)
}
