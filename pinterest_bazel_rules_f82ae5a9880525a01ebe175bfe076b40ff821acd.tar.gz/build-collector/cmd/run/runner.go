package run

import (
	"bufio"
	"bytes"
	"fmt"
	"os/exec"
)

type CmdRunner struct {
	Dir string
}

func NewCmdRunner() *CmdRunner {
	return &CmdRunner{}
}

func (r *CmdRunner) SetDir(dir string) {
	r.Dir = dir
}

func (r *CmdRunner) Run(command string, args ...string) ([]string, error) {
	var (
		err    error
		stderr bytes.Buffer
	)

	cmd := exec.Command(command, args...)
	cmd.Dir = r.Dir
	cmd.Stderr = &stderr

	readCloser, err := cmd.StdoutPipe()
	if err != nil {
		return nil, fmt.Errorf("%s:\n\n %s", err, stderr.String())
	}

	channel := make(chan struct{})

	scanner := bufio.NewScanner(readCloser)
	scanner.Split(bufio.ScanWords)
	lines := []string{}

	go func() {
		for scanner.Scan() {
			line := scanner.Text()
			lines = append(lines, line)
		}

		channel <- struct{}{}

	}()

	err = cmd.Start()
	if err != nil {
		return nil, fmt.Errorf("%s:\n\n %s", err, stderr.String())
	}

	<-channel

	err = cmd.Wait()
	if err != nil {
		return nil, fmt.Errorf("%s:\n\n %s", err, stderr.String())
	}

	return lines, err
}

func (r *CmdRunner) RunQuery(statement string) ([]string, error) {
	args := []string{"-c", fmt.Sprintf("bazel query '%s'", statement)}

	output, err := r.Run("bash", args...)
	if err != nil {
		err = fmt.Errorf("[ bazel query '%s' ]: %s", statement, err)
	}

	return output, err
}

func (r *CmdRunner) RunOrderQuery(statement string) ([]string, error) {
	args := []string{"-c", fmt.Sprintf("bazel query --order_output=full '%s'", statement)}

	output, err := r.Run("bash", args...)
	if err != nil {
		err = fmt.Errorf("[ bazel query '%s' ]: %s", statement, err)
	}

	return output, err
}

func (r *CmdRunner) RunSkyQuery(statement string) ([]string, error) {
	query := fmt.Sprintf("bazel query --order_output=no --universe_scope='//...' '%s'", statement)
	args := []string{"-c", query}

	output, err := r.Run("bash", args...)
	if err != nil {
		err = fmt.Errorf("[ %s ]: %s", query, err)
	}

	return output, err
}
