package cmd_test

import (
	"fmt"
	"io/ioutil"
	"os"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	"github.com/golang/mock/gomock"
	"pinterest.com/bazel-rules/build-collector/cmd"
)

var _ = Describe("get-test-workloads", func() {
	var (
		mockCtrl *gomock.Controller
		gtwCmd   cmd.GetTestWorkloadsCmd
		tempDir  string
		err      error
	)

	BeforeEach(func() {
		mockCtrl = gomock.NewController(GinkgoT())
		gtwCmd = cmd.NewGetTestWorkloadsCmd()

		tempDir, err = ioutil.TempDir("", "get-test-workloads")
		Expect(err).NotTo(HaveOccurred())
	})

	AfterEach(func() {
		mockCtrl.Finish()
		os.RemoveAll(tempDir)
	})

	Context("CalculateBatch", func() {
		It("generates the batch of workloads", func() {
			gtwCmd.CPU = 1
			workload := cmd.Workload{
				Targets: []cmd.TestTarget{
					cmd.TestTarget{
						Label:   ":some-target",
						Timeout: 5,
					},
					cmd.TestTarget{
						Label:   ":another-target",
						Timeout: 5,
					},
					cmd.TestTarget{
						Label:   ":other-target",
						Timeout: 15,
					},
				},
			}

			batch := gtwCmd.CalculateBatch(workload.Targets)
			Expect(batch).To(Equal(
				cmd.Batch{
					CPUTime:           15,
					NumberOfWorkloads: 2,
					Workloads: [][]string{
						[]string{":some-target", ":another-target"},
						[]string{":other-target"},
					},
				},
			))
		})
	})

	Context("Error Cases", func() {
		Context("When the path to the list of test targets does not exist", func() {
			It("returns an error", func() {
				gtwCmd.TargetsPath = "does-not-exist.json"

				err := gtwCmd.Run()
				Expect(err).To(MatchError("Failed to find test target file \"does-not-exist.json\": stat does-not-exist.json: no such file or directory"))
			})
		})

		Context("When there are no targets in the targets file", func() {
			var targetFilename string
			BeforeEach(func() {
				targetFile, err := ioutil.TempFile(tempDir, "targets.json")
				Expect(err).NotTo(HaveOccurred())

				_, err = targetFile.Write([]byte(`{}`))
				Expect(err).NotTo(HaveOccurred())

				gtwCmd.CPU = 1
				targetFilename = targetFile.Name()
				gtwCmd.TargetsPath = targetFilename
			})

			It("returns an error and does not create a workload file", func() {
				err := gtwCmd.Run()
				expectedErrorMessage := fmt.Sprintf("No test targets found in %q. Workload file not created.", gtwCmd.TargetsPath)
				Expect(err).To(MatchError(expectedErrorMessage))
			})
		})

		Context("When parsing the json in the target file fails", func() {
			BeforeEach(func() {
				invalidJSONFile, err := ioutil.TempFile(tempDir, "invalid-json")
				Expect(err).NotTo(HaveOccurred())

				_, err = invalidJSONFile.Write([]byte(`%%%%%%%`))
				Expect(err).NotTo(HaveOccurred())

				gtwCmd.TargetsPath = invalidJSONFile.Name()
			})

			It("returns an error", func() {
				err = gtwCmd.Run()
				expectedErrorMessage := fmt.Sprintf("Failed to parse JSON in %q: invalid character '%%' looking for beginning of value", gtwCmd.TargetsPath)
				Expect(err).To(MatchError(expectedErrorMessage))
			})
		})

		Context("When writing the JSON file fails", func() {
			BeforeEach(func() {
				targetsPath, err := ioutil.TempFile(tempDir, "targetsPath")
				Expect(err).NotTo(HaveOccurred())

				_, err = targetsPath.Write([]byte(`{"targets": [{"label": "//some-target"}]}`))
				Expect(err).NotTo(HaveOccurred())

				gtwCmd.TargetsPath = targetsPath.Name()
			})

			It("returns an error", func() {
				gtwCmd.OutputFile = "dir-doesnt-exist/blah.json"

				err = gtwCmd.Run()
				Expect(err).To(MatchError("Failed to write JSON file with workload information to \"dir-doesnt-exist/blah.json\": open dir-doesnt-exist/blah.json: no such file or directory"))
			})
		})
	})
})
