package cmd

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"os"
	"sort"

	"github.com/sirupsen/logrus"
	"github.com/spf13/cobra"
	"pinterest.com/bazel-rules/build-collector/cmd/bazel"
	"pinterest.com/bazel-rules/build-collector/cmd/collect"
)

type GetTestTargetsCmd struct {
	Analyzer   Analyzer
	Collector  Collector
	Dir        string
	OutputFile string
}

func NewGetTestTargetsCmd(analyzer Analyzer, collector Collector) GetTestTargetsCmd {
	return GetTestTargetsCmd{
		Analyzer:  analyzer,
		Collector: collector,
	}
}

func NewGTTCmd() *cobra.Command {
	collector := collect.NewCollector()
	analyzer := bazel.NewAnalyzer()
	gtt := NewGetTestTargetsCmd(analyzer, collector)

	cmd := &cobra.Command{
		Use:   "get-test-targets",
		Short: "Returns bazel test targets",
		Long:  `Finds the affected bazel test targets based on two git commits and writes them to a JSON file`,
		RunE: func(cmd *cobra.Command, args []string) error {
			return gtt.Run()
		},
	}

	flags := cmd.Flags()
	flags.StringVarP(&gtt.Dir, "directory", "d", "", "directory to read from (required)")
	flags.StringVarP(&collector.PreviousCommit, "previous-commit", "p", "", "previous commit to compare from (required)")
	flags.StringVarP(&collector.LatestCommit, "latest-commit", "l", "", "latest commit to compare to (required)")
	flags.StringVarP(&gtt.OutputFile, "output-file", "o", "test-targets.json", "path to result file of test targets")

	cmd.MarkFlagRequired("directory")
	cmd.MarkFlagRequired("previous-commit")
	cmd.MarkFlagRequired("latest-commit")

	return cmd
}

func (gtt *GetTestTargetsCmd) Run() error {
	logrus.Infof("verifying directory %q exists...", gtt.Dir)
	if _, err := os.Stat(gtt.Dir); os.IsNotExist(err) {
		return fmt.Errorf("Failed to find directory %q: %s", gtt.Dir, err)
	}

	logrus.Info("collecting modified files...")
	fileCollection, err := gtt.Collector.Files(gtt.Dir)
	if err != nil {
		return fmt.Errorf("Failed to collect files: %s", err)
	}

	logrus.Info("collecting affected bazel test targets...")
	targets, err := gtt.Analyzer.FindTests(gtt.Dir, fileCollection)
	if err != nil {
		return fmt.Errorf("Failed to find tests: %s", err)
	}

	logrus.Info("formatting results to JSON...")
	results := FormatResults(formatTest(targets), fileCollection)
	file, err := json.MarshalIndent(results, "", " ")
	if err != nil {
		return fmt.Errorf("Failed to marshall JSON: %s", err)
	}

	logrus.Infof("writing results to %q...", gtt.OutputFile)
	if err := ioutil.WriteFile(gtt.OutputFile, file, 0644); err != nil {
		return fmt.Errorf("Failed to write JSON file with test target information to %q: %s", gtt.OutputFile, err)
	}

	return nil
}

func FormatResults(targets []Target, fileCollection collect.FileCollection) TargetResults {
	results := TargetResults{}
	results.NumberOfTargets = len(targets)
	results.ChangedFiles = fileCollection

	logrus.Debugf("Found %d targets", results.NumberOfTargets)

	sort.Slice(targets, func(i, j int) bool {
		return targets[i].Label < targets[j].Label
	})

	results.Targets = targets
	return results
}

func formatTest(targets map[string]int) []Target {
	result := []Target{}
	for label, timeout := range targets {
		target := Target{
			Label:   label,
			Timeout: timeout,
		}
		result = append(result, target)
	}

	return result
}
