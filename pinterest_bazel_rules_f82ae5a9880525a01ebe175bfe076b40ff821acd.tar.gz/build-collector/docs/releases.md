# Release Notes

## 0.1.1
- commit: `63436fbb41e046144b82aaecc78548feb4094b57`
- bug fix: remove duplicate results in `get-release-targets` output

## 0.1.0
- commit: `d20e345871802225ec6a871b1b36463a2fd05ad9`
- first release of build-collector
