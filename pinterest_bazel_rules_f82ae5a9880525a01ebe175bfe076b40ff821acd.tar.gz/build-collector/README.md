# build-collector

Go binary that finds the changed files between two commits and reports the bazel targets to be built.
Check out release notes in `build-collector/docs/releases.md`.

## Installing

To install build-collector locally, clone this repo and build the binary. The binary can be built with either `bazel` or `go`.

### Build with go

```
git clone https://phabricator.pinadmin.com/source/bazel-rules.git
cd bazel-rules/build-collector

# Install build-collector to $GOPATH/bin
go install
build-collector --help

# Alternatively, build the binary in the current directory
go build .
./build-collector --help
```

### Build with Bazel

Please use the [[ .bazelversion/ | supported version of bazel ]].

```
git clone https://phabricator.pinadmin.com/source/bazel-rules.git
cd bazel-rules

# Install build-collector to bazel-bin directory
bazel run //build-collector
./bazel-bin/build-collector/<platform>/build-collector --help
```

## Usage

```
A simple CLI for finding bazel targets to build.

Usage:
  build-collector [command]

Available Commands:
  get-targets Returns bazel targets.
  help        Help about any command

Flags:
  -h, --help   help for build-collector

Use "build-collector [command] --help" for more information about a command.
```

## Running Tests

The `build-collector` tests are written with the `ginkgo` testing framework. The tests can be run with either `bazel` or `ginkgo`. If you'd like to run them with `ginkgo`, you'll need to have the `ginkgo` binary installed locally. Instructions for doing so can be found [here](https://onsi.github.io/ginkgo/).

### Running tests with bazel

```
# run all tests
bazel query 'kind("_test", //build-collector/...)' | xargs bazel test --test_output=errors

# run unit tests
bazel test --test_output=errors //build-collector/cmd:go_default_test
bazel test --test_output=errors //build-collector/cmd/bazel:go_default_test

# run integration tests
bazel test --test_output=errors //build-collector/acceptance:go_default_test
```

### Running tests with ginkgo

```
cd build-collector

# run all of the tests
ginkgo -r .

# run integration tests only
ginkgo -r acceptance

# run unit tests only
ginkgo -r cmd
```

### bazel-test-repo

In order to run integration tests, `build-collector` uses an example repository called `bazel-test-repo`. This repo is brought in as a git submdoule. Initalizing and updating the submodule can be done in one command by running `git submodule update --init --recursive`.

## Committing Changes

Before commiting to this project please ensure that you have done the following steps and ran all tests:

```
# Update the go modules. This command will update the go.mod & go.sum files
go mod tidy

# Update bazel's BUILD files and generate new ones if needed
bazel run //:gazelle

# Generate dependencies for bazel. This command will use the go.mod file to generate go_repository rules and add them to the deps.bzl file in this repo. Check if the added repositories in pinterest/deps.bzl are actually being used before commiting this file.
bazel run //:gazelle -- update-repos -from_file go.mod -to_macro pinterest/deps.bzl%pinterest_deps -prune
```

### Making updates to the bazel-test-repo (for tests)

The bazel-test-repo repo is a git submodule used for acceptance tests. The following steps are reqiured to make new changes available to both test runners (ginkgo and bazel).

- Commit the changes to the submodule repo and update the subproject commit in the bazel-rules repo
- ssh into a jenkins worker locally (not from devapp). We do this because the jenkins workers have access to the AWS S3 Dev buckets
- git clone the bazel-test-repo and create a tarball of it. Version the tarball by adding the first 13 characters of the latest git sha.
- get the shasum of the tarball
- upload the tarball to the S3 bucket `build-collector-artifacts`
- update the shasum and tarball path in the [[ ../pinterest/repositories.bzl | repositories.bzl file ]]

```
  gironde query <jenkins-worker-prefix>
  gironde ssh -A <jenkins-worker-name>
  git clone ssh://git@phabricator.pinadmin.com/diffusion/1347/bazel-test-repo.git (make sure your new changes are included here)
  tar -czvf bazel-test-repo-<git-sha>.tar.gz bazel-test-repo
  sha256sum bazel-test-repo-<git-sha>.tar.gz
  aws s3 cp bazel-test-repo-<git-sha>.tar.gz s3://pinterest-builds/build-collector-artifacts/bazel-test-repo-<git-sha>.tar.gz
  # update repositories.bzl with the shashum and path to the artifact
```
