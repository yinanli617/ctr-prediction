package acceptance_test

import (
	"fmt"
	"io/ioutil"
	"os"
	"os/exec"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"

	"github.com/onsi/gomega/gexec"
	"pinterest.com/bazel-rules/build-collector/cmd"
)

var _ = Describe("Acceptance", func() {
	var (
		tempDir    string
		resultFile string
	)

	BeforeEach(func() {
		tempDir, err := ioutil.TempDir("", "acceptance-test-dir")
		Expect(err).NotTo(HaveOccurred())

		resultFile = fmt.Sprintf("%s/targets.json", tempDir)
	})
	AfterEach(func() {
		os.RemoveAll(tempDir)
	})

	Context("When running the build-collector cli", func() {
		It("exits with status code 0", func() {
			cmd := exec.Command(cmdPath)
			session, err := gexec.Start(cmd, GinkgoWriter, GinkgoWriter)

			Expect(err).NotTo(HaveOccurred())
			Eventually(session).Should(gexec.Exit(0))
		})
	})

	Context("When running get-test-targets", func() {
		It("returns the affected test targets to the specified JSON output file", func() {
			args := []string{
				"get-test-targets",
				"--directory", bazelTestRepoPath,
				"--previous-commit", TEST_PREV_COMMIT,
				"--latest-commit", TEST_LATEST_COMMIT,
				"--output-file", resultFile,
			}

			Expect(resultFile).ToNot(BeAnExistingFile())
			gttCmd := exec.Command(cmdPath, args...)
			session, err := gexec.Start(gttCmd, GinkgoWriter, GinkgoWriter)

			Expect(err).NotTo(HaveOccurred())
			Eventually(session.Wait(10)).Should(gexec.Exit(0))
			Expect(resultFile).To(BeAnExistingFile())

			result := parseTargetResultFile(resultFile)
			Expect(result.NumberOfTargets).To(Equal(4))

			Expect(result.ChangedFiles.WORKSPACE).To(BeTrue())
			Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some-dir-with-BUILD/some_file.sh"))
			Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some_file.sh"))
			Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some_test_file.sh"))
			Expect(result.ChangedFiles.BUILDFiles).To(ContainElement("BUILD.bazel"))
			Expect(result.ChangedFiles.BUILDFiles).To(ContainElement("some-dir-with-BUILD/BUILD.bazel"))

			By("including test targets affected by source file changes", func() {
				Expect(result.Targets).To(Equal([]cmd.Target{
					//test target affected by source file change
					cmd.Target{
						Label:   "//:short_test_target",
						Timeout: 1,
					},
					//test target affected by source file change
					cmd.Target{
						Label:   "//:test_target",
						Timeout: 5,
					},
					//test target affected by source file change
					cmd.Target{
						Label:   "//some-dir-with-BUILD:large_test_target",
						Timeout: 15,
					},
					//test target affected by bazel file change
					cmd.Target{
						Label:   "//some-dir-with-BUILD:test_target",
						Timeout: 5,
					},
				}))
			})

			By("excluding test targets tagged with no-ci, manual, or both", func() {
				Expect(result.Targets).NotTo(ContainElement("//:test_target_no_ci"))
				Expect(result.Targets).NotTo(ContainElement("//:test_target_manual"))
				Expect(result.Targets).NotTo(ContainElement("//:test_target_manual_and_no_ci"))
			})
		})
	})

	Context("When running get-test-workloads", func() {
		It("returns the number of workloads, a complete list of workloads, and their CPUTime", func() {
			args := []string{
				"get-test-workloads",
				"--test-targets", testFixturePath,
				"--cpu", "2",
				"--output-file", resultFile,
			}

			Expect(resultFile).ToNot(BeAnExistingFile())
			cmd := exec.Command(cmdPath, args...)
			session, err := gexec.Start(cmd, GinkgoWriter, GinkgoWriter)

			Expect(err).NotTo(HaveOccurred())
			Eventually(session.Wait(10)).Should(gexec.Exit(0))
			Expect(resultFile).To(BeAnExistingFile())

			batch := parseWorkloadResultFile(resultFile)
			Expect(batch.CPUTime).To(Equal(10))
			Expect(batch.NumberOfWorkloads).To(Equal(2))
			Expect(batch.Workloads).To(Equal([][]string{
				[]string{"//:moderate-c", "//:moderate-d"},
				[]string{"//:short-a", "//:short-b", "//tests:moderate-a", "//tests:short-b", "//tests:short-c"},
			}))
		})
	})

	Context("When running get-build-targets", func() {
		It("returns the affected build targets to the specified JSON output file", func() {
			args := []string{
				"get-build-targets",
				"--directory", bazelTestRepoPath,
				"--previous-commit", TEST_PREV_COMMIT,
				"--latest-commit", TEST_LATEST_COMMIT,
				"--output-file", resultFile,
			}

			Expect(resultFile).ToNot(BeAnExistingFile())
			gttCmd := exec.Command(cmdPath, args...)
			session, err := gexec.Start(gttCmd, GinkgoWriter, GinkgoWriter)

			Expect(err).NotTo(HaveOccurred())
			Eventually(session.Wait(10)).Should(gexec.Exit(0))
			Expect(resultFile).To(BeAnExistingFile())

			result := parseTargetResultFile(resultFile)
			Expect(result.NumberOfTargets).To(Equal(2))

			Expect(result.ChangedFiles.WORKSPACE).To(BeTrue())
			Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some-dir-with-BUILD/some_file.sh"))
			Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some_file.sh"))
			Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some_test_file.sh"))
			Expect(result.ChangedFiles.BUILDFiles).To(ContainElement("BUILD.bazel"))
			Expect(result.ChangedFiles.BUILDFiles).To(ContainElement("some-dir-with-BUILD/BUILD.bazel"))

			By("including build targets affected by source file changes", func() {
				Expect(result.Targets).To(Equal([]cmd.Target{
					//build targets affected by source file change
					cmd.Target{
						Label: "//:build_target",
					},
					cmd.Target{
						Label: "//some-dir-with-BUILD:build_target",
					},
				}))
			})

			By("excluding test targets tagged with no-ci, manual, or both", func() {
				Expect(result.Targets).NotTo(ContainElement("//some-dir-with-BUILD:build_target_no_ci"))
				Expect(result.Targets).NotTo(ContainElement("//some-dir-with-BUILD:build_target_manual"))
				Expect(result.Targets).NotTo(ContainElement("//some-dir-with-BUILD:build_target_manual_and_no_ci"))
			})
		})
	})

	Context("When running get-release-targets", func() {
		It("returns the affected release targets to the specified JSON output file", func() {
			args := []string{
				"get-release-targets",
				"--directory", bazelTestRepoPath,
				"--previous-commit", TEST_PREV_COMMIT,
				"--latest-commit", TEST_LATEST_COMMIT,
				"--output-file", resultFile,
			}

			Expect(resultFile).ToNot(BeAnExistingFile())
			gttCmd := exec.Command(cmdPath, args...)
			session, err := gexec.Start(gttCmd, GinkgoWriter, GinkgoWriter)

			Expect(err).NotTo(HaveOccurred())
			Eventually(session.Wait(10)).Should(gexec.Exit(0))
			Expect(resultFile).To(BeAnExistingFile())

			result := parseTargetResultFile(resultFile)
			Expect(result.NumberOfTargets).To(Equal(2))

			Expect(result.ChangedFiles.WORKSPACE).To(BeTrue())
			Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some-dir-with-BUILD/some_file.sh"))
			Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some_file.sh"))
			Expect(result.ChangedFiles.SourceFiles).To(ContainElement("some_test_file.sh"))
			Expect(result.ChangedFiles.BUILDFiles).To(ContainElement("BUILD.bazel"))
			Expect(result.ChangedFiles.BUILDFiles).To(ContainElement("some-dir-with-BUILD/BUILD.bazel"))

			By("including release targets affected by source file changes", func() {
				Expect(result.Targets).To(Equal([]cmd.Target{
					cmd.Target{
						Label:   "//:release_target",
					},
					cmd.Target{
						Label:   "//some-dir-with-BUILD:release_target",
					},
				}))
			})
		})
	})
})
