package acceptance_test

import (
	"bytes"
	"flag"
	"fmt"
	"io/ioutil"
	"os"
	"os/exec"
	"testing"

	. "github.com/onsi/ginkgo"
	. "github.com/onsi/gomega"
	"github.com/onsi/gomega/gexec"
)

var (
	withBazel         bool
	bazelTestRepoPath string
	cmdPath           string
	testRepoTarPath   string
	testFixturePath   string
)

const TEST_LATEST_COMMIT = "b46d69e963352f46eecfa045d3e95021ade53e6f"
const TEST_PREV_COMMIT = "f222f8272d7aabe0a927288b567b4de02d004c7b"

func init() {
	flag.StringVar(&cmdPath, "cmdPath", "", "path to bazel's build of build-collector")
	flag.StringVar(&testRepoTarPath, "testRepoTarPath", "", "path to tar of bazel-test-repo")
	flag.StringVar(&testFixturePath, "testFixturePath", "", "path to test fixture")
	flag.BoolVar(&withBazel, "withBazel", false, "boolean knowing if the tests are run with bazel")
}

func TestAcceptance(t *testing.T) {
	RegisterFailHandler(Fail)
	RunSpecs(t, "Acceptance Test Suite")
}

var _ = BeforeSuite(func() {
	projectDir, err := os.Getwd()
	Expect(err).NotTo(HaveOccurred())

	if withBazel {
		bazelSetup(projectDir)
	} else {
		ginkgoSetup(projectDir)
	}
})

var _ = AfterSuite(func() {
	gexec.CleanupBuildArtifacts()
})

func ginkgoSetup(projectDir string) {
	var err error

	cmdPath, err = gexec.Build("pinterest.com/bazel-rules/build-collector")
	Expect(err).NotTo(HaveOccurred())

	bazelTestRepoPath = fmt.Sprintf("%s/bazel-test-repo", projectDir)
	testFixturePath = fmt.Sprintf("%s/fixtures/test-targets.json", projectDir)
}

func bazelSetup(projectDir string) {
	var err error

	tempDir, err := ioutil.TempDir("", "cache-dir")
	Expect(err).NotTo(HaveOccurred())

	bazelTestRepoPath, err = untar(fmt.Sprintf("%s/%s", projectDir, testRepoTarPath), tempDir)
	Expect(err).NotTo(HaveOccurred())

	err = os.Setenv("XDG_CACHE_HOME", tempDir)
	Expect(err).NotTo(HaveOccurred())
}

func untar(path string, dir string) (string, error) {
	var (
		err    error
		out    bytes.Buffer
		stderr bytes.Buffer
	)

	if _, err := os.Stat(path); os.IsNotExist(err) {
		return "", fmt.Errorf("Failed to find file to untar %q: %s", path, err)
	}

	cmd := exec.Command("tar", "-xvf", path)
	cmd.Dir = dir
	cmd.Stdout = &out
	cmd.Stderr = &stderr

	if err = cmd.Run(); err != nil {
		return "", fmt.Errorf("%s:\n %s", err, stderr.String())
	}

	return fmt.Sprintf("%s/bazel-test-repo", dir), nil
}
