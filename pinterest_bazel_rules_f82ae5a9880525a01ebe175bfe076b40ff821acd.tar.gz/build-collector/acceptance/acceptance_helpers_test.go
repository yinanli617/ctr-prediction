package acceptance_test

import (
	"encoding/json"
	"io/ioutil"

	. "github.com/onsi/gomega"
	"pinterest.com/bazel-rules/build-collector/cmd"
)

type TestBatch struct {
	CPUTime           int        `json:"CPUTime"`
	NumberOfWorkloads int        `json:"numberOfWorkloads"`
	Workloads         [][]string `json:"workloads"`
}

func parseTargetResultFile(file string) cmd.TargetResults {
	fileContents, err := ioutil.ReadFile(file)
	Expect(err).NotTo(HaveOccurred())

	result := cmd.TargetResults{}
	err = json.Unmarshal(fileContents, &result)
	Expect(err).NotTo(HaveOccurred())

	return result
}

func parseWorkloadResultFile(file string) TestBatch {
	fileContents, err := ioutil.ReadFile(file)
	Expect(err).NotTo(HaveOccurred())

	batch := TestBatch{}
	err = json.Unmarshal(fileContents, &batch)
	Expect(err).NotTo(HaveOccurred())
	return batch
}
