package main

import "pinterest.com/bazel-rules/build-collector/cmd"

func main() {
	cmd.Execute()
}
