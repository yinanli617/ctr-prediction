// +build go1.7 !go1.8

package platforms
