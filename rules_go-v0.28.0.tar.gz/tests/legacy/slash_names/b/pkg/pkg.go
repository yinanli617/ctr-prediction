package pkg

func Name() string {
	return "B"
}
