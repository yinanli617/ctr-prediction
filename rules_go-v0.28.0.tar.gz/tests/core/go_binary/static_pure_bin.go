package main

import (
	_ "net"
	_ "os"
)

func main() {}
