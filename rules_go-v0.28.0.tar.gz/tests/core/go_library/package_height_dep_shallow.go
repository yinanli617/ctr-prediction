package dep

type T struct{}
