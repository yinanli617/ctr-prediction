#include "examples/test_cc_shared_library/bar4.h"

int bar4() { return 42; }
