#include "examples/test_cc_shared_library/qux.h"

int qux() { return 42; }
